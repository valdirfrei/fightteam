<?php
/*
Plugin Name: Fight Team Aluno
Description: Um plugin para exibir o perfil do aluno com informações como faixa, exames, e mensalidades, acessível para assinantes.
Version: 1.0.0
Author: Seu Nome
Text Domain: fight-team-aluno
*/

// Impedir acesso direto
if (!defined('ABSPATH')) {
    exit;
}

// Carregar a classe principal
require_once plugin_dir_path(__FILE__) . 'includes/class-fight-team-aluno.php';

// Inicializar o plugin
new Fight_Team_Aluno();
?>