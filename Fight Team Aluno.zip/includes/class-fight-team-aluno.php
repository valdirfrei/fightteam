<?php
// includes/class-fight-team-aluno.php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class Fight_Team_Aluno {
    public function __construct() {
        add_action('admin_menu', array($this, 'add_aluno_menu'));
        add_action('init', array($this, 'register_custom_capabilities'));
        error_log('Fight_Team_Aluno: Constructor called');
    }

    public function register_custom_capabilities() {
        $subscriber_role = get_role('subscriber');
        if ($subscriber_role) {
            $subscriber_role->add_cap('fight_team_subscriber');
        }
        error_log('Fight_Team_Aluno: Custom capability fight_team_subscriber registered');
    }

    public function add_aluno_menu() {
        add_menu_page(
            __('Perfil Aluno', 'fight-team-aluno'),
            __('Perfil Aluno', 'fight-team-aluno'),
            'fight_team_subscriber',
            'fight-team-aluno',
            array($this, 'render_aluno_profile'),
            'dashicons-id-alt',
            7
        );
        error_log('Fight_Team_Aluno: Aluno profile menu added');
    }

    /**
     * Placeholder function to fetch and store Facebook profile photo
     * Implement this to integrate with Facebook Graph API
     */
    private function fetch_facebook_profile_photo($user_email, $facebook_id = null) {
        // TODO: Implement Facebook Graph API integration
        // 1. Use Facebook SDK or HTTP client to call: https://graph.facebook.com/{facebook_id}/picture?type=large&redirect=false&access_token={access_token}
        // 2. Download the image from the returned URL
        // 3. Upload to WordPress media library using media_handle_sideload()
        // 4. Update the photo_url in the database
        // Example pseudocode:
        /*
        global $wpdb;
        $access_token = 'your-app-access-token'; // Obtain via Facebook SDK or OAuth
        $response = wp_remote_get("https://graph.facebook.com/{$facebook_id}/picture?type=large&redirect=false&access_token={$access_token}");
        if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200) {
            $data = json_decode(wp_remote_retrieve_body($response), true);
            $image_url = $data['data']['url'] ?? '';
            if ($image_url) {
                // Download and upload to WordPress
                $image = media_sideload_image($image_url, 0, 'Facebook Profile Photo', 'src');
                if (!is_wp_error($image)) {
                    // Update database
                    $wpdb->update(
                        "{$wpdb->prefix}fight_team_students",
                        ['photo_url' => $image],
                        ['email' => $user_email],
                        ['%s'],
                        ['%s']
                    );
                    return $image;
                }
            }
        }
        */
        return false;
    }

    public function render_aluno_profile() {
        if (!current_user_can('fight_team_subscriber')) {
            wp_die(__('Sem permissão para acessar esta página.', 'fight-team-aluno'));
        }

        if (!is_user_logged_in()) {
            wp_die(__('Você precisa estar logado para acessar esta página.', 'fight-team-aluno'));
        }

        global $wpdb;
        $academy_name = get_option('fight_team_academy_name', 'Minha Academia');
        $current_user = wp_get_current_user();
        $user_email = strtolower($current_user->user_email);

        // Optionally fetch Facebook profile photo if not set
        // $facebook_id = get_user_meta($current_user->ID, 'facebook_id', true); // Store Facebook ID in user meta
        // if (empty($student->photo_url) && $facebook_id) {
        //     $this->fetch_facebook_profile_photo($user_email, $facebook_id);
        // }

        $student = $wpdb->get_row($wpdb->prepare(
            "SELECT id, full_name, email, birth_date, start_date, belt_level, exam_dates, payment_due_day, photo_url, brazilian_confederation, federation, weight, height
             FROM {$wpdb->prefix}fight_team_students
             WHERE LOWER(email) = %s",
            $user_email
        ));

        error_log('Fight_Team_Aluno: Rendering aluno profile page for email: ' . $user_email);
        error_log('Fight_Team_Aluno: Student query result: ' . ($student ? print_r($student, true) : 'No student found'));

        ?>
        <div class="wrap">
            <h1><?php echo esc_html($academy_name); ?> - <?php _e('Perfil Aluno', 'fight-team-aluno'); ?></h1>
            <?php if ($student): ?>
                <h2><?php _e('Seu Perfil', 'fight-team-aluno'); ?></h2>
                <?php
                $last_payment = $wpdb->get_row($wpdb->prepare(
                    "SELECT status, due_date
                     FROM {$wpdb->prefix}fight_team_payments
                     WHERE student_id = %d
                     ORDER BY due_date DESC
                     LIMIT 1",
                    $student->id
                ));

                error_log('Fight_Team_Aluno: Last payment query result: ' . ($last_payment ? print_r($last_payment, true) : 'No payment found'));

                $full_name = !empty($student->full_name) ? esc_html($student->full_name) : __('Não informado', 'fight-team-aluno');
                $birth_date = !empty($student->birth_date) ? esc_html($student->birth_date) : __('Não informado', 'fight-team-aluno');
                $age = !empty($student->birth_date) ? (new DateTime($student->birth_date))->diff(new DateTime())->y . ' anos' : __('Não informado', 'fight-team-aluno');
                $current_belt = !empty($student->belt_level) ? esc_html($student->belt_level) : __('Não informado', 'fight-team-aluno');
                $payment_due_day = !empty($student->payment_due_day) ? esc_html($student->payment_due_day) : __('Não informado', 'fight-team-aluno');
                $payment_status = $last_payment ? ($last_payment->status === 'paid' ? __('Pago', 'fight-team-aluno') : __('Pendente', 'fight-team-aluno')) : __('Não Pago', 'fight-team-aluno');
                // Validate photo_url to ensure it's a valid URL; fallback to placeholder if invalid or empty
                $photo_url = !empty($student->photo_url) && filter_var($student->photo_url, FILTER_VALIDATE_URL) ? esc_url($student->photo_url) : 'https://via.placeholder.com/80?text=Sem+Foto';
                $brazilian_confederation = !empty($student->brazilian_confederation) ? esc_html($student->brazilian_confederation) : __('Não informado', 'fight-team-aluno');
                $federation = !empty($student->federation) ? esc_html($student->federation) : __('Não informado', 'fight-team-aluno');
                $weight = !empty($student->weight) ? esc_html($student->weight) . ' kg' : __('Não informado', 'fight-team-aluno');
                $height = !empty($student->height) ? esc_html($student->height) . ' m' : __('Não informado', 'fight-team-aluno');

                $start_date = !empty($student->start_date) ? new DateTime($student->start_date) : null;
                $current_date = new DateTime();
                $training_time = $start_date ? $start_date->diff($current_date) : null;
                $training_time_str = $training_time ? sprintf('%d anos, %d meses', $training_time->y, $training_time->m) : __('Não informado', 'fight-team-aluno');

                error_log('Fight_Team_Aluno: Rendered fields - Name: ' . $full_name . ', Birth Date: ' . $birth_date . ', Age: ' . $age . ', Belt: ' . $current_belt . ', Training Time: ' . $training_time_str . ', Due Day: ' . $payment_due_day . ', Payment Status: ' . $payment_status . ', Photo URL: ' . $photo_url . ', Confederation: ' . $brazilian_confederation . ', Federation: ' . $federation . ', Weight: ' . $weight . ', Height: ' . $height);
                ?>
                <table style="width: 100%; border-collapse: collapse; border: 1px solid #000; font-size: 16px;">
                    <tr style="border: 1px solid #000;">
                        <td colspan="2" style="padding: 10px;"><strong><?php _e('Nome:', 'fight-team-aluno'); ?></strong> <?php echo $full_name; ?></td>
                    </tr>
                    <tr style="border: 1px solid #000;">
                        <td style="padding: 10px; border-right: 1px solid #000; width: 50%;"><strong><?php _e('D. Nasc.:', 'fight-team-aluno'); ?></strong> <?php echo $birth_date; ?></td>
                        <td style="padding: 10px; width: 50%;"><strong><?php _e('Idade:', 'fight-team-aluno'); ?></strong> <?php echo $age; ?></td>
                    </tr>
                    <tr style="border: 1px solid #000;">
                        <td style="padding: 10px; border-right: 1px solid #000; width: 50%;"><strong><?php _e('Faixa:', 'fight-team-aluno'); ?></strong> <?php echo $current_belt; ?></td>
                        <td style="padding: 10px; width: 50%;"><strong><?php _e('Tempo de Treino:', 'fight-team-aluno'); ?></strong> <?php echo $training_time_str; ?></td>
                    </tr>
                    <tr style="border: 1px solid #000;">
                        <td style="padding: 10px; border-right: 1px solid #000; width: 50%;"><strong><?php _e('Peso:', 'fight-team-aluno'); ?></strong> <?php echo $weight; ?></td>
                        <td style="padding: 10px; width: 50%;"><strong><?php _e('Altura:', 'fight-team-aluno'); ?></strong> <?php echo $height; ?></td>
                    </tr>
                    <tr style="border: 1px solid #000;">
                        <td style="padding: 10px; border-right: 1px solid #000; width: 50%;"><strong><?php _e('Data Venc.:', 'fight-team-aluno'); ?></strong> <?php echo $payment_due_day; ?></td>
                        <td style="padding: 10px; width: 50%;"><strong><?php _e('Mensal.:', 'fight-team-aluno'); ?></strong> <?php echo $payment_status; ?></td>
                    </tr>
                    <tr style="border: 1px solid #000;">
                        <td style="padding: 10px; border-right: 1px solid #000; width: 50%;"><strong><?php _e('Confederação:', 'fight-team-aluno'); ?></strong> <?php echo $brazilian_confederation; ?></td>
                        <td style="padding: 10px; width: 50%;"><strong><?php _e('Federação:', 'fight-team-aluno'); ?></strong> <?php echo $federation; ?></td>
                    </tr>
                </table>

                <!-- Carteirinha Digital -->
                <h2 style="margin-top: 30px;"><?php _e('Carteirinha Digital', 'fight-team-aluno'); ?></h2>
                <div style="width: 300px; height: 200px; border: 2px solid #000; background-color: #e6f0fa; padding: 10px; font-family: Arial, sans-serif; box-shadow: 2px 2px 5px rgba(0,0,0,0.2); border-radius: 10px;">
                    <div style="display: flex; align-items: center; border-bottom: 1px solid #000; padding-bottom: 5px; margin-bottom: 10px;">
                        <img src="<?php echo esc_url(get_site_icon_url() ?: 'https://via.placeholder.com/30?text=Logo'); ?>" alt="Logo" style="width: 30px; height: 30px; margin-right: 10px;">
                        <span style="font-size: 14px; font-weight: bold;"><?php echo esc_html($academy_name); ?></span>
                    </div>
                    <div style="display: flex;">
                        <img src="<?php echo $photo_url; ?>" alt="Foto do Aluno" style="width: 80px; height: 80px; border: 1px solid #000; margin-right: 10px; object-fit: cover;">
                        <div style="font-size: 12px;">
                            <p><strong><?php _e('Nome:', 'fight-team-aluno'); ?></strong> <?php echo $full_name; ?></p>
                            <p><strong><?php _e('D. Nasc.:', 'fight-team-aluno'); ?></strong> <?php echo $birth_date; ?></p>
                            <p><strong><?php _e('Faixa:', 'fight-team-aluno'); ?></strong> <?php echo $current_belt; ?></p>
                            <p><strong><?php _e('Confederação:', 'fight-team-aluno'); ?></strong> <?php echo $brazilian_confederation; ?></p>
                            <p><strong><?php _e('Federação:', 'fight-team-aluno'); ?></strong> <?php echo $federation; ?></p>
                        </div>
                    </div>
                </div>
            <?php else: ?>
                <p><?php printf(__('Nenhum perfil de aluno encontrado para o email: %s. Entre em contato com a administração.', 'fight-team-aluno'), esc_html($user_email)); ?></p>
            <?php endif; ?>
        </div>
        <?php
        error_log('Fight_Team_Aluno: Aluno profile page rendered');
    }
}
?>