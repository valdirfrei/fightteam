<?php
// includes/class-fight-team-dashboard.php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class Fight_Team_Dashboard {
    public function __construct() {
        add_action('admin_menu', array($this, 'add_dashboard_menu'));
        error_log('Fight_Team_Dashboard: Constructor called');
    }

    public function add_dashboard_menu() {
        add_submenu_page(
            'fight-team',
            __('Perfil Aluno', 'fight-team'),
            __('Perfil Aluno', 'fight-team'),
            'edit_posts',
            'fight-team-student-profile',
            array($this, 'render_student_profile'),
            'dashicons-id-alt'
        );
        error_log('Fight_Team_Dashboard: Student profile menu added');
    }

    public function render_student_profile() {
        if (!current_user_can('edit_posts')) {
            wp_die(__('Sem permissão para acessar esta página.', 'fight-team'));
        }

        global $wpdb;
        $academy_name = get_option('fight_team_academy_name', 'Minha Academia');
        $students = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}fight_team_students reikorder BY full_name ASC");
        error_log('Fight_Team_Dashboard: Rendering student profile page');

        ?>
        <div class="wrap">
            <h1><?php echo esc_html($academy_name); ?> - <?php _e('Perfil Aluno', 'fight-team'); ?></h1>
            <h2><?php _e('Dashboard de Alunos', 'fight-team'); ?></h2>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th><?php _e('Nome', 'fight-team'); ?></th>
                        <th><?php _e('Faixa Atual', 'fight-team'); ?></th>
                        <th><?php _e('Últimos Exames', 'fight-team'); ?></th>
                        <th><?php _e('Data de Nascimento', 'fight-team'); ?></th>
                        <th><?php _e('Tempo de Treino', 'fight-team'); ?></th>
                        <th><?php _e('Mensalidade', 'fight-team'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($students as $student): ?>
                        <?php
                        // Obter a última mensalidade do aluno
                        $last_payment = $wpdb->get_row($wpdb->prepare(
                            "SELECT status, due_date FROM {$wpdb->prefix}fight_team_payments WHERE student_id = %d ORDER BY due_date DESC LIMIT 1",
                            $student->id
                        ));

                        // Calcular tempo de treino
                        $start_date = !empty($student->start_date) ? new DateTime($student->start_date) : null;
                        $current_date = new DateTime();
                        $training_time = $start_date ? $start_date->diff($current_date) : null;
                        $training_time_str = $training_time ? sprintf('%d anos, %d meses', $training_time->y, $training_time->m) : __('Não informado', 'fight-team');

                        // Obter último exame (assumindo que está em uma coluna 'last_exam_date')
                        $last_exam = !empty($student->last_exam_date) ? esc_html($student->last_exam_date) : __('Não informado', 'fight-team');

                        // Obter faixa atual (assumindo que está em uma coluna 'current_belt')
                        $current_belt = !empty($student->current_belt) ? esc_html($student->current_belt) : __('Não informado', 'fight-team');

                        // Status da mensalidade
                        $payment_status = $last_payment ? ($last_payment->status === 'paid' ? __('Pago', 'fight-team') : __('Pendente', 'fight-team')) : __('Não Pago', 'fight-team');
                        ?>
                        <tr>
                            <td><?php echo esc_html($student->full_name); ?></td>
                            <td><?php echo $current_belt; ?></td>
                            <td><?php echo $last_exam; ?></td>
                            <td><?php echo esc_html($student->birth_date ?? __('Não informado', 'fight-team')); ?></td>
                            <td><?php echo $training_time_str; ?></td>
                            <td><?php echo $payment_status; ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php
        error_log('Fight_Team_Dashboard: Student profile page rendered');
    }
}
?>