<?php
/*
Plugin Name: Fight Team
Description: Gerenciamento de alunos, turmas, mensalidades, presença e dashboards para academias de artes marciais.
Version: 2.1
Author: Valdir de Freitas 
email: valdirfrei@hotmail.com
Doação : https://www.vakinha.com.br/5508287
*/

// Evitar acesso direto ao arquivo
if (!defined('ABSPATH')) {
    exit;
}

// Definir constantes
define('FT_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('FT_PLUGIN_URL', plugin_dir_url(__FILE__));

// Incluir arquivos necessários
require_once FT_PLUGIN_DIR . 'includes/class-fight-team-db.php';
require_once FT_PLUGIN_DIR . 'includes/class-fight-team-admin.php';
require_once FT_PLUGIN_DIR . 'includes/class-fight-team-frontend.php';
//require_once FT_PLUGIN_DIR . 'includes/fight-team-class-students.php';
require_once FT_PLUGIN_DIR . 'includes/class-fight-team-classes-dashboard.php';
require_once FT_PLUGIN_DIR . 'includes/class-fight-team-payments-dashboard.php';
require_once FT_PLUGIN_DIR . 'includes/class-fight-team-payments.php';
require_once FT_PLUGIN_DIR . 'includes/class-fight-team-cadeditaluno.php';
require_once FT_PLUGIN_DIR . 'includes/class-fight-team-student-details.php';
require_once FT_PLUGIN_DIR . 'includes/class-fight-team-backup.php';
require_once FT_PLUGIN_DIR . 'includes/class-fight-team-attendance.php';
require_once FT_PLUGIN_DIR . 'includes/class-fight-team-attendance-dashboard.php';




// Inicializar o plugin
function fight_team_init() {
    // Inicializar banco de dados
    $db = new Fight_Team_DB();
    $db->create_tables();

    // Inicializar administração
    $admin = new Fight_Team_Admin();

    // Inicializar frontend
    $frontend = new Fight_Team_Frontend();

    // Inicializar dashboard de turmas
    $classes_dashboard = new Fight_Team_Classes_Dashboard();

    // Inicializar dashboard de pagamentos
    $payments_dashboard = new Fight_Team_Payments_Dashboard();

    // Inicializar gerenciamento de mensalidades
    $payments = new Fight_Team_Payments();

    // Inicializar gerenciamento de alunos
    $student_management = new Fight_Team_Student_Management();
        // Inicializar detalhes do aluno
        
        // detalhes estudante
    $student_details = new Fight_Team_Student_Details();
    
        // Inicializar backup
    $backup = new Fight_Team_Backup();
    
        // Inicializar presenças
    $attendance = new Fight_Team_Attendance();
    
    // Inicializar dashboard de presenças
  $attendance_dashboard = new Fight_Team_Attendance_Dashboard();
  
    // Inicializar classe 
  //$attendance_class = new ight_Team_Class_Students();
  
  
  

}
add_action('plugins_loaded', 'fight_team_init');

// Ativar o plugin
register_activation_hook(__FILE__, function() {
    $db = new Fight_Team_DB();
    $db->create_tables();
});

// Desativar o plugin
register_deactivation_hook(__FILE__, function() {
    // Código de desativação, se necessário
});

// Traduções
function fight_team_load_textdomain() {
    load_plugin_textdomain('fight-team', false, dirname(plugin_basename(__FILE__)) . '/languages/');
}
add_action('init', 'fight_team_load_textdomain');
?>