# Fight Team Plugin

## Descrição
O **Fight Team** é um plugin de código aberto para WordPress projetado para gerenciar academias de artes marciais. Ele permite o cadastro de alunos, controle de mensalidades, registro de presenças, turmas e detalhes adicionais como datas de exames de faixa. Este plugin é ideal para academias que desejam organizar informações de alunos e gerenciar suas operações de forma eficiente diretamente no painel do WordPress.

Este projeto é de **código fonte aberto** e está licenciado sob a GNU General Public License v2 ou superior. Você é livre para usar, modificar e distribuir o código conforme os termos da licença.

## Licença
Este plugin é distribuído sob a **GNU General Public License v2 ou superior**. Isso significa que você pode:
- Usar o plugin para qualquer finalidade, incluindo projetos comerciais.
- Modificar o código para atender às suas necessidades.
- Distribuir o plugin ou suas modificações.
- Contribuir com melhorias para o projeto.

Para mais detalhes, consulte o arquivo `LICENSE.txt` (se incluído) ou visite: https://www.gnu.org/licenses/gpl-2.0.html

## Instalação
1. Faça o download do plugin (ou clone o repositório, se disponível).
2. Extraia a pasta `fight-team` para o diretório `/wp-content/plugins/` do seu WordPress.
3. Acesse o painel de administração do WordPress.
4. Vá para **Plugins** > **Plugins Instalados** e ative o "Fight Team".
5. As tabelas do banco de dados serão criadas automaticamente na ativação.
6. Acesse o menu **Fight Team** no painel para começar a usar.

## Como Usar
- **Gerenciar Alunos**: Adicione, edite ou exclua alunos no menu **Fight Team** > **Dashboard**.
- **Mensalidades**: Registre e acompanhe pagamentos no mesmo menu.
- **Detalhes do Aluno**: Consulte informações detalhadas, como datas de exames, no menu **Detalhes do Aluno**.
- **Configurações**: Personalize o nome da academia em **Fight Team** > **Configurações**.

## Contribuindo
Como um projeto de código aberto, encorajamos contribuições! Para contribuir:
1. Faça um fork do repositório (se hospedado em plataformas como GitHub).
2. Crie uma branch para suas alterações (`git checkout -b minha-nova-funcionalidade`).
3. Commit suas mudanças (`git commit -m 'Adiciona nova funcionalidade'`).
4. Envie um pull request com uma descrição clara das alterações.
5. Respeite as diretrizes de código do WordPress (https://developer.wordpress.org/coding-standards/).

Se você encontrar bugs ou tiver sugestões, por favor, abra uma issue no repositório do projeto ou entre em contato com o desenvolvedor.

## Requisitos
- WordPress 5.0 ou superior.
- PHP 7.4 ou superior.
- MySQL 5.7 ou superior (ou MariaDB equivalente).

## Autor
Desenvolvido por Valdir de Freitas Pinto. Contribuições da comunidade são bem-vindas!

## Aviso
Este plugin é fornecido "como está", sem garantias. Certifique-se de fazer backup do seu banco de dados antes de instalar ou modificar o plugin.

Faça uma Doação!
https://www.vakinha.com.br/5508287