<?php
// includes/class-fight-team-payments-dashboard.php
class Fight_Team_Payments_Dashboard {
    public function __construct() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
        add_shortcode('fight_team_payments_dashboard', array($this, 'render_payments_dashboard_shortcode'));
        error_log('Fight_Team_Payments_Dashboard: Construtor chamado');
    }

    public function add_admin_menu() {
        add_submenu_page(
            'fight-team', // Slug do menu pai
            __('Dashboard Mensalidades', 'fight-team'), // Título da página
            __('Dashboard Mensalidades', 'fight-team'), // Título do menu
            'manage_options', // Capacidade
            'fight-team-payments-dashboard', // Slug do menu
            array($this, 'render_payments_dashboard') // Função de callback
        );
        error_log('Fight_Team_Payments_Dashboard: Submenu adicionado ao Fight Team');
    }

    public function enqueue_admin_scripts($hook) {
        if (strpos($hook, 'fight-team-payments-dashboard') !== false) {
            wp_enqueue_style('fight-team-admin', FT_PLUGIN_URL . 'assets/css/admin.css', array(), '2.0');
            wp_enqueue_script('fight-team-admin', FT_PLUGIN_URL . 'assets/js/admin.js', array('jquery'), '2.0', true);
            wp_localize_script('fight-team-admin', 'fightTeamAjax', array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('fight_team_nonce')
            ));
            error_log('Fight_Team_Payments_Dashboard: Scripts enfileirados para o hook: ' . $hook);
        }
    }

    public function render_payments_dashboard_shortcode($atts) {
        global $wpdb;
        error_log('Fight_Team_Payments_Dashboard: Renderizando shortcode do dashboard de mensalidades');

        // Verificar permissões
        if (!current_user_can('manage_options')) {
            return '<p>' . __('Você não tem permissão para acessar esta área.', 'fight-team') . '</p>';
        }

        // Enfileirar estilos para o frontend
        wp_enqueue_style('fight-team-shortcode', FT_PLUGIN_URL . 'assets/css/admin.css', array(), '2.0');

        // Obter o ano atual
        $current_year = date('Y'); // 2025, conforme data atual

        // Lista de meses
        $months = array(
            '1' => __('Janeiro', 'fight-team'),
            '2' => __('Fevereiro', 'fight-team'),
            '3' => __('Março', 'fight-team'),
            '4' => __('Abril', 'fight-team'),
            '5' => __('Maio', 'fight-team'),
            '6' => __('Junho', 'fight-team'),
            '7' => __('Julho', 'fight-team'),
            '8' => __('Agosto', 'fight-team'),
            '9' => __('Setembro', 'fight-team'),
            '10' => __('Outubro', 'fight-team'),
            '11' => __('Novembro', 'fight-team'),
            '12' => __('Dezembro', 'fight-team'),
        );

        // Obter mês selecionado
        $selected_month = isset($_POST['month_filter']) ? intval($_POST['month_filter']) : 0;

        // Montar a consulta SQL
        $sql = "SELECT p.*, s.full_name FROM {$wpdb->prefix}fight_team_payments p 
                JOIN {$wpdb->prefix}fight_team_students s ON p.student_id = s.id 
                WHERE p.status = 'paid' AND YEAR(p.paid_date) = %d";
        $params = array($current_year);

        if ($selected_month && array_key_exists($selected_month, $months)) {
            $sql .= " AND MONTH(p.paid_date) = %d";
            $params[] = $selected_month;
        }

        $payments = $wpdb->get_results($wpdb->prepare($sql, $params));
        error_log('Fight_Team_Payments_Dashboard: Mensalidades encontradas (ano ' . $current_year . ', mês ' . ($selected_month ?: 'todos') . '): ' . count($payments));

        ob_start();
        ?>
        <div class="wrap fight-team-shortcode">
            <h1><?php _e('Dashboard Mensalidades', 'fight-team'); ?></h1>
            <a href="<?php echo admin_url('admin.php?page=fight-team'); ?>" class="button button-primary"><?php _e('Voltar ao Dashboard Principal', 'fight-team'); ?></a>
            <a href="<?php echo admin_url('admin.php?page=fight-team-payments'); ?>" class="button button-primary"><?php _e('Gerenciar Mensalidades', 'fight-team'); ?></a>

            <h2><?php _e('Mensalidades Pagas', 'fight-team'); ?></h2>
            <form method="post" class="payments-filter-form">
                <?php wp_nonce_field('fight_team_payments_nonce', 'fight_team_payments_nonce'); ?>
                <label for="month_filter"><?php _e('Filtrar por Mês', 'fight-team'); ?>:</label>
                <select name="month_filter" id="month_filter">
                    <option value=""><?php _e('Todos os meses', 'fight-team'); ?></option>
                    <?php foreach ($months as $month_num => $month_name): ?>
                        <option value="<?php echo esc_attr($month_num); ?>" <?php echo $selected_month == $month_num ? 'selected' : ''; ?>>
                            <?php echo esc_html($month_name); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <input type="submit" class="button" value="<?php _e('Filtrar', 'fight-team'); ?>">
            </form>

            <?php if (empty($payments)): ?>
                <p><?php _e('Nenhuma mensalidade paga encontrada para o período selecionado.', 'fight-team'); ?></p>
            <?php else: ?>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th><?php _e('Aluno', 'fight-team'); ?></th>
                            <th><?php _e('Valor', 'fight-team'); ?></th>
                            <th><?php _e('Data de Vencimento', 'fight-team'); ?></th>
                            <th><?php _e('Status', 'fight-team'); ?></th>
                            <th><?php _e('Data de Pagamento', 'fight-team'); ?></th>
                            <th><?php _e('Ações', 'fight-team'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($payments as $payment): ?>
                            <tr>
                                <td><?php echo esc_html($payment->full_name); ?></td>
                                <td><?php echo esc_html(number_format($payment->amount, 2, ',', '.')); ?></td>
                                <td><?php echo esc_html($payment->due_date); ?></td>
                                <td><?php echo esc_html($payment->status); ?></td>
                                <td><?php echo esc_html($payment->paid_date ?: '-'); ?></td>
                                <td>
                                    <a href="<?php echo admin_url('admin.php?page=fight-team-payments&id=' . $payment->id); ?>"><?php _e('Editar', 'fight-team'); ?></a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
        <?php
        $output = ob_get_clean();
        error_log('Fight_Team_Payments_Dashboard: Shortcode do dashboard de mensalidades renderizado');
        return $output;
    }

    public function render_payments_dashboard() {
        global $wpdb;
        error_log('Fight_Team_Payments_Dashboard: Renderizando dashboard');
        ?>
        <div class="wrap">
            <?php echo $this->render_payments_dashboard_shortcode(array()); ?>
        </div>
        <?php
        error_log('Fight_Team_Payments_Dashboard: Dashboard renderizado');
    }
}
?>