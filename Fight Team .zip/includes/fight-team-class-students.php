<?php
// includes/fight-team-class-students.php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class Fight_Team_Class_Students {
    public function __construct() {
        add_action('admin_menu', array($this, 'add_class_students_menu'));
        error_log('Fight_Team_Class_Students: Constructor called');
    }

    public function add_class_students_menu() {
        add_submenu_page(
            'fight-team',
            __('Alunos por Turma', 'fight-team'),
            __('Alunos por Turma', 'fight-team'),
            'edit_posts',
            'fight-team-class-students',
            array($this, 'render_class_students_page')
        );
        error_log('Fight_Team_Class_Students: Class students menu added');
    }

    public function render_class_students_page() {
        if (!current_user_can('edit_posts')) {
            wp_die(__('Você não tem permissão para acessar esta página.', 'fight-team'));
        }

        global $wpdb;
        $academy_name = get_option('fight_team_academy_name', 'Minha Academia');
        $classes = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}fight_team_classes");
        $selected_class_id = isset($_POST['class_id']) ? intval($_POST['class_id']) : 0;
        $students = [];

        if ($selected_class_id && isset($_POST['fight_team_class_students_nonce']) && wp_verify_nonce($_POST['fight_team_class_students_nonce'], 'fight_team_class_students_nonce')) {
            $current_date = new DateTime();
            $month_start = $current_date->format('Y-m-01');
            $month_end = $current_date->format('Y-m-t');

            $students = $wpdb->get_results($wpdb->prepare(
                "SELECT s.id, s.full_name, s.active, s.start_date 
                 FROM {$wpdb->prefix}fight_team_students s 
                 JOIN {$wpdb->prefix}fight_team_class_students cs 
                 ON s.id = cs.student_id 
                 WHERE cs.class_id = %d AND s.active = 1",
                $selected_class_id
            ));
        }

        error_log('Fight_Team_Class_Students: Rendering class students page');
        ?>
        <div class="wrap fight-team-class-students">
            <h1><?php echo esc_html($academy_name); ?> - <?php _e('Alunos por Turma', 'fight-team'); ?></h1>
            <?php if (empty($classes)): ?>
                <p><?php _e('Nenhuma turma disponível para seleção.', 'fight-team'); ?></p>
            <?php else: ?>
                <form method="post" class="class-students-form">
                    <?php wp_nonce_field('fight_team_class_students_nonce', 'fight_team_class_students_nonce'); ?>
                    <label for="class_id"><?php _e('Selecione uma Turma', 'fight-team'); ?>:</label>
                    <select name="class_id" id="class_id">
                        <option value=""><?php _e('Selecione uma turma', 'fight-team'); ?></option>
                        <?php foreach ($classes as $class): ?>
                            <option value="<?php echo esc_attr($class->id); ?>" <?php selected($selected_class_id, $class->id); ?>>
                                <?php echo esc_html($class->name); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <input type="submit" class="button" value="<?php _e('Filtrar', 'fight-team'); ?>">
                </form>

                <?php if ($selected_class_id): ?>
                    <?php if (empty($students)): ?>
                        <p><?php _e('Nenhum aluno ativo inscrito nesta turma.', 'fight-team'); ?></p>
                    <?php else: ?>
                        <table class="wp-list-table widefat fixed striped">
                            <thead>
                                <tr>
                                    <th><?php _e('Nome do Aluno', 'fight-team'); ?></th>
                                    <th><?php _e('Status', 'fight-team'); ?></th>
                                    <th><?php _e('Presenças no Mês', 'fight-team'); ?></th>
                                    <th><?php _e('Tempo de Treino', 'fight-team'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $current_date = new DateTime();
                                $month_start = $current_date->format('Y-m-01');
                                $month_end = $current_date->format('Y-m-t');
                                foreach ($students as $student):
                                    $attendances = $wpdb->get_var($wpdb->prepare(
                                        "SELECT COUNT(*) 
                                         FROM {$wpdb->prefix}fight_team_attendances 
                                         WHERE student_id = %d 
                                         AND class_id = %d 
                                         AND attendance_date BETWEEN %s AND %s 
                                         AND present = 1",
                                        $student->id,
                                        $selected_class_id,
                                        $month_start,
                                        $month_end
                                    ));

                                    $training_time = '-';
                                    if ($student->start_date) {
                                        $start = new DateTime($student->start_date);
                                        $interval = $start->diff($current_date);
                                        $years = $interval->y;
                                        $months = $interval->m;
                                        $days = $interval->d;
                                        $training_time = sprintf(
                                            __('%d ano(s), %d mês(es), %d dia(s)', 'fight-team'),
                                            $years,
                                            $months,
                                            $days
                                        );
                                    }
                                    ?>
                                    <tr>
                                        <td><?php echo esc_html($student->full_name); ?></td>
                                        <td><?php echo $student->active ? __('Ativo', 'fight-team') : __('Inativo', 'fight-team'); ?></td>
                                        <td><?php echo esc_html($attendances); ?></td>
                                        <td><?php echo esc_html($training_time); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                <?php else: ?>
                    <p><?php _e('Selecione uma turma para ver os alunos ativos.', 'fight-team'); ?></p>
                <?php endif; ?>
            <?php endif; ?>
        </div>
        <?php
        error_log('Fight_Team_Class_Students: Class students page rendered');
    }

    // Manter o shortcode para compatibilidade
    public function render_class_students_shortcode() {
        ob_start();
        $this->render_class_students_page();
        return ob_get_clean();
    }
}

if (class_exists('Fight_Team_Class_Students')) {
    $class_students = new Fight_Team_Class_Students();
    add_shortcode('fight_team_class_students', [$class_students, 'render_class_students_shortcode']);
}
?>