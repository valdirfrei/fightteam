<?php
// includes/class-fight-team-cadeditaluno.php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class Fight_Team_Student_Management {
    public function __construct() {
        add_action('admin_menu', array($this, 'add_student_menu'));
        error_log('Fight_Team_Student_Management: Constructor called');
    }

    public function add_student_menu() {
        add_submenu_page(
            'fight-team',
            __('Cadastrar/Editar Aluno', 'fight-team'),
            __('Cadastrar Aluno', 'fight-team'),
            'edit_posts',
            'fight-team-student',
            array($this, 'render_student_form')
        );
        error_log('Fight_Team_Student_Management: Student menu added');
    }

    public function render_student_form() {
        if (!current_user_can('edit_posts')) {
            wp_die(__('Sem permissão para acessar esta página.', 'fight-team'));
        }

        global $wpdb;
        error_log('Fight_Team_Student_Management: Rendering student form');
        $student = null;
        $error_message = '';

        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $student = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}fight_team_students WHERE id = %d", $id));
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['fight_team_student_nonce']) && wp_verify_nonce($_POST['fight_team_student_nonce'], 'save_student')) {
            $data = array(
                'full_name' => sanitize_text_field($_POST['full_name']),
                'birth_date' => sanitize_text_field($_POST['birth_date']),
                'address' => sanitize_textarea_field($_POST['address']),
                'phone' => sanitize_text_field($_POST['phone']),
                'email' => sanitize_email($_POST['email']),
                'city' => sanitize_text_field($_POST['city']),
                'state' => sanitize_text_field($_POST['state']),
                'zip_code' => sanitize_text_field($_POST['zip_code']),
                'belt_level' => sanitize_text_field($_POST['belt_level']),
                'start_date' => sanitize_text_field($_POST['start_date']),
                'exam_dates' => sanitize_textarea_field($_POST['exam_dates']),
                'guardian' => sanitize_text_field($_POST['guardian']),
                'guardian_phone' => sanitize_text_field($_POST['guardian_phone']),
                'medical_info' => sanitize_textarea_field($_POST['medical_info']),
                'rg' => sanitize_text_field($_POST['rg']),
                'cpf' => sanitize_text_field($_POST['cpf']),
                'international_membership' => sanitize_text_field($_POST['international_membership']),
                'brazilian_confederation' => sanitize_text_field($_POST['brazilian_confederation']),
                'federation' => sanitize_text_field($_POST['federation']),
                'payment_due_day' => intval($_POST['payment_due_day']),
                'weight' => floatval($_POST['weight']),
                'height' => floatval($_POST['height']),
                'active' => isset($_POST['active']) ? 1 : 0,
                'user_id' => intval($_POST['user_id']),
            );

            // Processar upload da foto
            if (!empty($_FILES['photo']['name']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
                require_once ABSPATH . 'wp-admin/includes/file.php';
                $uploaded = wp_handle_upload($_FILES['photo'], array('test_form' => false));

                if ($uploaded && !isset($uploaded['error'])) {
                    $data['photo_url'] = $uploaded['url'];
                } else {
                    $error_message = isset($uploaded['error']) ? $uploaded['error'] : __('Erro ao fazer upload da foto.', 'fight-team');
                }
            } else {
                $data['photo_url'] = $student ? $student->photo_url : '';
            }

            if (!$error_message) {
                if ($student) {
                    $wpdb->update($wpdb->prefix . 'fight_team_students', $data, array('id' => $student->id));
                } else {
                    $data['created_at'] = current_time('mysql');
                    $wpdb->insert($wpdb->prefix . 'fight_team_students', $data);
                }
                wp_redirect(admin_url('admin.php?page=fight-team'));
                exit;
            }
        }

        $users = get_users(array('role__in' => array('subscriber', 'editor', 'author', 'administrator')));
        ?>
        <div class="wrap">
            <h1><?php echo $student ? __('Editar Aluno', 'fight-team') : __('Novo Aluno', 'fight-team'); ?></h1>
            <?php if ($error_message): ?>
                <div class="error"><p><?php echo esc_html($error_message); ?></p></div>
            <?php endif; ?>
            <form method="post" enctype="multipart/form-data">
                <?php wp_nonce_field('save_student', 'fight_team_student_nonce'); ?>
                <table class="form-table">
                    <tr>
                        <th><label for="full_name"><?php _e('Nome Completo', 'fight-team'); ?> *</label></th>
                        <td><input type="text" name="full_name" id="full_name" value="<?php echo $student ? esc_attr($student->full_name) : ''; ?>" required class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><label for="birth_date"><?php _e('Data de Nascimento', 'fight-team'); ?> *</label></th>
                        <td><input type="date" name="birth_date" id="birth_date" value="<?php echo $student ? esc_attr($student->birth_date) : ''; ?>" required></td>
                    </tr>
                    <tr>
                        <th><label for="address"><?php _e('Endereço', 'fight-team'); ?> *</label></th>
                        <td><textarea name="address" id="address" rows="4" class="regular-text"><?php echo $student ? esc_textarea($student->address) : ''; ?></textarea></td>
                    </tr>
                    <tr>
                        <th><label for="phone"><?php _e('Telefone', 'fight-team'); ?> *</label></th>
                        <td><input type="text" name="phone" id="phone" value="<?php echo $student ? esc_attr($student->phone) : ''; ?>" required class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><label for="email"><?php _e('Email', 'fight-team'); ?> *</label></th>
                        <td><input type="email" name="email" id="email" value="<?php echo $student ? esc_attr($student->email) : ''; ?>" required class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><label for="city"><?php _e('Cidade', 'fight-team'); ?> *</label></th>
                        <td><input type="text" name="city" id="city" value="<?php echo $student ? esc_attr($student->city) : ''; ?>" required class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><label for="state"><?php _e('Estado', 'fight-team'); ?> *</label></th>
                        <td><input type="text" name="state" id="state" value="<?php echo $student ? esc_attr($student->state) : ''; ?>" required class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><label for="zip_code"><?php _e('CEP', 'fight-team'); ?> *</label></th>
                        <td><input type="text" name="zip_code" id="zip_code" value="<?php echo $student ? esc_attr($student->zip_code) : ''; ?>" required class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><label for="weight"><?php _e('Peso (kg)', 'fight-team'); ?></label></th>
                        <td><input type="number" step="0.1" name="weight" id="weight" value="<?php echo $student ? esc_attr($student->weight) : ''; ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><label for="height"><?php _e('Altura (m)', 'fight-team'); ?></label></th>
                        <td><input type="number" step="0.01" name="height" id="height" value="<?php echo $student ? esc_attr($student->height) : ''; ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><label for="belt_level"><?php _e('Faixa Atual', 'fight-team'); ?></label></th>
                        <td><input type="text" name="belt_level" id="belt_level" value="<?php echo $student ? esc_attr($student->belt_level) : ''; ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><label for="start_date"><?php _e('Data de Início', 'fight-team'); ?></label></th>
                        <td><input type="date" name="start_date" id="start_date" value="<?php echo $student ? esc_attr($student->start_date) : ''; ?>"></td>
                    </tr>
                    <tr>
                        <th><label for="exam_dates"><?php _e('Últimos Exames', 'fight-team'); ?></label></th>
                        <td><textarea name="exam_dates" id="exam_dates" rows="4" class="regular-text"><?php echo $student ? esc_textarea($student->exam_dates) : ''; ?></textarea></td>
                    </tr>
                    <tr>
                        <th><label for="guardian"><?php _e('Responsável', 'fight-team'); ?></label></th>
                        <td><input type="text" name="guardian" id="guardian" value="<?php echo $student ? esc_attr($student->guardian) : ''; ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><label for="guardian_phone"><?php _e('Telefone do Responsável', 'fight-team'); ?></label></th>
                        <td><input type="text" name="guardian_phone" id="guardian_phone" value="<?php echo $student ? esc_attr($student->guardian_phone) : ''; ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><label for="medical_info"><?php _e('Informações Médicas', 'fight-team'); ?></label></th>
                        <td><textarea name="medical_info" id="medical_info" rows="4" class="regular-text"><?php echo $student ? esc_textarea($student->medical_info) : ''; ?></textarea></td>
                    </tr>
                    <tr>
                        <th><label for="rg"><?php _e('RG', 'fight-team'); ?></label></th>
                        <td><input type="text" name="rg" id="rg" value="<?php echo $student ? esc_attr($student->rg) : ''; ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><label for="cpf"><?php _e('CPF', 'fight-team'); ?></label></th>
                        <td><input type="text" name="cpf" id="cpf" value="<?php echo $student ? esc_attr($student->cpf) : ''; ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><label for="international_membership"><?php _e('Inter. Membership', 'fight-team'); ?> *</label></th>
                        <td><input type="text" name="international_membership" id="international_membership" value="<?php echo $student ? esc_attr($student->international_membership) : ''; ?>" required class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><label for="brazilian_confederation"><?php _e('Confederação', 'fight-team'); ?> *</label></th>
                        <td><input type="text" name="brazilian_confederation" id="brazilian_confederation" value="<?php echo $student ? esc_attr($student->brazilian_confederation) : ''; ?>" required class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><label for="federation"><?php _e('Federação', 'fight-team'); ?> *</label></th>
                        <td><input type="text" name="federation" id="federation" value="<?php echo $student ? esc_attr($student->federation) : ''; ?>" required class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><label for="photo"><?php _e('Foto do Aluno', 'fight-team'); ?></label></th>
                        <td>
                            <?php if ($student && $student->photo_url): ?>
                                <p><img src="<?php echo esc_url($student->photo_url); ?>" alt="<?php _e('Foto do Aluno', 'fight-team'); ?>" style="max-width: 200px; height: auto;"></p>
                            <?php endif; ?>
                            <input type="file" name="photo" id="photo" accept="image/jpeg,image/png,image/gif">
                            <p class="description"><?php _e('Formatos aceitos: JPEG, PNG, GIF. Tamanho máximo: 2MB.', 'fight-team'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="payment_due_day"><?php _e('Dia de Vencimento', 'fight-team'); ?></label></th>
                        <td><input type="number" name="payment_due_day" id="payment_due_day" min="1" max="31" value="<?php echo $student ? esc_attr($student->payment_due_day) : ''; ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><label for="user_id"><?php _e('Usuário Vinculado', 'fight-team'); ?></label></th>
                        <td>
                            <select name="user_id" id="user_id">
                                <option value="0"><?php _e('Nenhum', 'fight-team'); ?></option>
                                <?php foreach ($users as $user): ?>
                                    <option value="<?php echo esc_attr($user->ID); ?>" <?php echo $student && $student->user_id == $user->ID ? 'selected' : ''; ?>>
                                        <?php echo esc_html($user->display_name . ' (' . $user->user_email . ')'); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="active"><?php _e('Ativo', 'fight-team'); ?></label></th>
                        <td><input type="checkbox" name="active" id="active" value="1" <?php echo $student && $student->active ? 'checked' : (!$student ? 'checked' : ''); ?>></td>
                    </tr>
                </table>
                <?php submit_button($student ? __('Atualizar Aluno', 'fight-team') : __('Adicionar Aluno', 'fight-team')); ?>
            </form>
        </div>
        <?php
        error_log('Fight_Team_Student_Management: Student form rendered');
    }
}
?>