<?php
// includes/class-fight-team-payments.php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class Fight_Team_Payments {
    public function __construct() {
        add_action('admin_menu', array($this, 'add_payments_menu'));
        error_log('Fight_Team_Payments: Constructor called');
    }

    public function add_payments_menu() {
        add_submenu_page(
            'fight-team',
            __('Gerenciar Mensalidades', 'fight-team'),
            __('Mensalidades', 'fight-team'),
            'edit_posts', // Alinhado com o menu principal
            'fight-team-payments',
            array($this, 'render_payments_form')
        );
        error_log('Fight_Team_Payments: Payments menu added');
    }

    public function render_payments_form() {
        if (!current_user_can('edit_posts')) {
            wp_die(__('Sem permissão para acessar esta página.', 'fight-team'));
        }

        global $wpdb;
        error_log('Fight_Team_Payments: Rendering payments form');
        $payment = null;
        $suggested_due_day = '';
        $selected_student_id = isset($_GET['student_id']) ? intval($_GET['student_id']) : 0;

        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $payment = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}fight_team_payments WHERE id = %d", $id));
            if ($payment) {
                $selected_student_id = $payment->student_id;
                $suggested_due_day = date('j', strtotime($payment->due_date));
            }
        }

        $students = $wpdb->get_results("SELECT id, full_name, payment_due_day FROM {$wpdb->prefix}fight_team_students WHERE active = 1");
        error_log('Fight_Team_Payments: Found ' . count($students) . ' active students');

        if (!$payment && $selected_student_id) {
            $student = $wpdb->get_row($wpdb->prepare("SELECT payment_due_day FROM {$wpdb->prefix}fight_team_students WHERE id = %d", $selected_student_id));
            if ($student && $student->payment_due_day) {
                $suggested_due_day = $student->payment_due_day;
            }
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['fight_team_payment_nonce']) && wp_verify_nonce($_POST['fight_team_payment_nonce'], 'save_payment')) {
            $due_day = intval($_POST['due_day']);
            $today = new DateTime();
            $current_day = (int)$today->format('d');
            $current_month = $today->format('m');
            $current_year = $today->format('Y');

            if ($current_day <= $due_day) {
                $due_date = sprintf('%04d-%02d-%02d', $current_year, $current_month, $due_day);
            } else {
                $next_month = $today->modify('+1 month');
                $due_date = sprintf('%04d-%02d-%02d', $next_month->format('Y'), $next_month->format('m'), $due_day);
            }

            $data = array(
                'student_id' => intval($_POST['student_id']),
                'amount' => floatval($_POST['amount']),
                'due_date' => sanitize_text_field($due_date),
                'status' => sanitize_text_field($_POST['status']),
                'paid_date' => $_POST['status'] === 'paid' ? sanitize_text_field($_POST['paid_date']) : null,
            );

            if ($payment) {
                $wpdb->update($wpdb->prefix . 'fight_team_payments', $data, array('id' => $payment->id));
            } else {
                $wpdb->insert($wpdb->prefix . 'fight_team_payments', $data);
            }
            wp_redirect(admin_url('admin.php?page=fight-team'));
            exit;
        }
        ?>
        <div class="wrap">
            <h1><?php echo $student ? __('Editar Mensalidade', 'fight-team') : __('Nova Mensalidade', 'fight-team'); ?></h1>
            <form method="post">
                <?php wp_nonce_field('save_payment', 'fight_team_payment_nonce'); ?>
                <table class="form-table">
                    <tr>
                        <th><label for="student_id"><?php _e('Aluno', 'fight-team'); ?> *</label></th>
                        <td>
                            <select name="student_id" id="student_id" required <?php echo $payment ? 'disabled' : 'onchange="window.location.href=\'' . admin_url('admin.php?page=fight-team-payments&student_id=') . '\' + this.value;"'; ?>>
                                <option value=""><?php _e('Selecione um aluno', 'fight-team'); ?></option>
                                <?php foreach ($students as $student): ?>
                                    <option value="<?php echo esc_attr($student->id); ?>" <?php echo $selected_student_id == $student->id ? 'selected' : ''; ?>>
                                        <?php echo esc_html($student->full_name); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <?php if ($payment): ?>
                                <input type="hidden" name="student_id" value="<?php echo esc_attr($payment->student_id); ?>">
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="amount"><?php _e('Valor', 'fight-team'); ?> *</label></th>
                        <td><input type="number" step="0.01" name="amount" id="amount" value="<?php echo $payment ? esc_attr($payment->amount) : ''; ?>" required class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><label for="due_day"><?php _e('Dia de Vencimento', 'fight-team'); ?> *</label></th>
                        <td>
                            <input type="number" name="due_day" id="due_day" min="1" max="31" value="<?php echo esc_attr($suggested_due_day); ?>" required>
                            <p class="description"><?php _e('Digite o dia do mês para o vencimento (1 a 31).', 'fight-team'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="status"><?php _e('Status', 'fight-team'); ?> *</label></th>
                        <td>
                            <select name="status" id="status" required>
                                <option value="pending" <?php echo $payment && $payment->status === 'pending' ? 'selected' : ''; ?>><?php _e('Pendente', 'fight-team'); ?></option>
                                <option value="paid" <?php echo $payment && $payment->status === 'paid' ? 'selected' : ''; ?>><?php _e('Pago', 'fight-team'); ?></option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="paid_date"><?php _e('Data de Pagamento', 'fight-team'); ?></label></th>
                        <td><input type="date" name="paid_date" id="paid_date" value="<?php echo $payment && $payment->paid_date ? esc_attr($payment->paid_date) : ''; ?>"></td>
                    </tr>
                </table>
                <?php submit_button($payment ? __('Atualizar Mensalidade', 'fight-team') : __('Adicionar Mensalidade', 'fight-team')); ?>
            </form>
        </div>
        <?php
        error_log('Fight_Team_Payments: Payments form rendered');
    }
}
?>