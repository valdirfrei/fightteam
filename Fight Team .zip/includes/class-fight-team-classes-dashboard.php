<?php
// includes/class-fight-team-classes-dashboard.php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class Fight_Team_Classes_Dashboard {
    public function __construct() {
        add_action('admin_menu', array($this, 'add_classes_dashboard_menu'));
        error_log('Fight_Team_Classes_Dashboard: Constructor called');
    }

    public function add_classes_dashboard_menu() {
        add_submenu_page(
            'fight-team',
            __('Gerenciar Turmas', 'fight-team'),
            __('Gerenciar Turmas', 'fight-team'),
            'edit_posts',
            'fight-team-classes',
            array($this, 'render_classes_dashboard_page')
        );
        error_log('Fight_Team_Classes_Dashboard: Classes dashboard menu added');
    }

    public function render_classes_dashboard_page() {
        if (!current_user_can('edit_posts')) {
            wp_die(__('Sem permissão para acessar esta página.', 'fight-team'));
        }

        global $wpdb;
        $academy_name = get_option('fight_team_academy_name', 'Minha Academia');
        $table_classes = $wpdb->prefix . 'fight_team_classes';
        $table_class_students = $wpdb->prefix . 'fight_team_class_students';
        $table_students = $wpdb->prefix . 'fight_team_students';

        // Processar ações (adicionar, editar, excluir)
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['fight_team_classes_nonce']) && wp_verify_nonce($_POST['fight_team_classes_nonce'], 'save_class')) {
            $data = [
                'name' => sanitize_text_field($_POST['class_name']),
                'instructor' => sanitize_text_field($_POST['instructor']),
                'schedule' => sanitize_text_field($_POST['schedule']),
                'days_of_week' => implode(',', array_map('sanitize_text_field', $_POST['days_of_week'] ?? [])),
            ];

            $class_id = isset($_POST['class_id']) ? intval($_POST['class_id']) : 0;
            $selected_students = isset($_POST['students']) ? array_map('intval', $_POST['students']) : [];

            if ($class_id) {
                // Atualizar turma existente
                $wpdb->update($table_classes, $data, ['id' => $class_id]);
            } else {
                // Adicionar nova turma
                $wpdb->insert($table_classes, $data);
                $class_id = $wpdb->insert_id;
            }

            // Atualizar alunos associados
            $wpdb->delete($table_class_students, ['class_id' => $class_id]);
            foreach ($selected_students as $student_id) {
                $wpdb->insert($table_class_students, [
                    'class_id' => $class_id,
                    'student_id' => $student_id,
                ]);
            }

            wp_redirect(admin_url('admin.php?page=fight-team-classes'));
            exit;
        }

        // Processar exclusão
        if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id']) && isset($_GET['_wpnonce'])) {
            if (wp_verify_nonce($_GET['_wpnonce'], 'delete_class_' . $_GET['id'])) {
                $id = intval($_GET['id']);
                $wpdb->delete($table_classes, ['id' => $id]);
                wp_redirect(admin_url('admin.php?page=fight-team-classes'));
                exit;
            } else {
                wp_die(__('Nonce inválido.', 'fight-team'));
            }
        }

        // Obter turma para edição
        $class = null;
        $class_students = [];
        if (isset($_GET['action']) && $_GET['action'] === 'edit' && isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $class = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_classes WHERE id = %d", $id));
            $class_students = $wpdb->get_col($wpdb->prepare("SELECT student_id FROM $table_class_students WHERE class_id = %d", $id));
        }

        // Listar turmas e alunos
        $classes = $wpdb->get_results("SELECT * FROM $table_classes ORDER BY name ASC");
        $students = $wpdb->get_results("SELECT id, full_name FROM $table_students WHERE active = 1 ORDER BY full_name ASC");

        error_log('Fight_Team_Classes_Dashboard: Rendering classes dashboard page');
        ?>
        <div class="wrap">
            <h1><?php echo esc_html($academy_name); ?> - <?php _e('Gerenciar Turmas', 'fight-team'); ?></h1>

            <!-- Formulário para adicionar/editar turma -->
            <h2><?php echo $class ? __('Editar Turma', 'fight-team') : __('Adicionar Nova Turma', 'fight-team'); ?></h2>
            <form method="post">
                <?php wp_nonce_field('save_class', 'fight_team_classes_nonce'); ?>
                <?php if ($class): ?>
                    <input type="hidden" name="class_id" value="<?php echo esc_attr($class->id); ?>">
                <?php endif; ?>
                <table class="form-table">
                    <tr>
                        <th><label for="class_name"><?php _e('Nome da Turma', 'fight-team'); ?></label></th>
                        <td><input type="text" name="class_name" id="class_name" value="<?php echo $class ? esc_attr($class->name) : ''; ?>" required class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><label for="instructor"><?php _e('Professor Responsável', 'fight-team'); ?></label></th>
                        <td><input type="text" name="instructor" id="instructor" value="<?php echo $class ? esc_attr($class->instructor) : ''; ?>" required class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><label for="schedule"><?php _e('Horário', 'fight-team'); ?></label></th>
                        <td><input type="text" name="schedule" id="schedule" value="<?php echo $class ? esc_attr($class->schedule) : ''; ?>" required class="regular-text" placeholder="<?php _e('Ex.: 19:00-20:00', 'fight-team'); ?>"></td>
                    </tr>
                    <tr>
                        <th><label for="days_of_week"><?php _e('Dias da Semana', 'fight-team'); ?></label></th>
                        <td>
                            <?php
                            $days = ['Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb', 'Dom'];
                            $selected_days = $class && $class->days_of_week ? explode(',', $class->days_of_week) : [];
                            foreach ($days as $day):
                            ?>
                                <label>
                                    <input type="checkbox" name="days_of_week[]" value="<?php echo esc_attr($day); ?>" <?php checked(in_array($day, $selected_days)); ?>>
                                    <?php echo esc_html($day); ?>
                                </label>
                            <?php endforeach; ?>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="students"><?php _e('Alunos', 'fight-team'); ?></label></th>
                        <td>
                            <select name="students[]" id="students" multiple size="5" class="regular-text">
                                <?php foreach ($students as $student): ?>
                                    <option value="<?php echo esc_attr($student->id); ?>" <?php echo in_array($student->id, $class_students) ? 'selected' : ''; ?>>
                                        <?php echo esc_html($student->full_name); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <p class="description"><?php _e('Segure Ctrl para selecionar múltiplos alunos.', 'fight-team'); ?></p>
                        </td>
                    </tr>
                </table>
                <?php submit_button($class ? __('Atualizar Turma', 'fight-team') : __('Adicionar Turma', 'fight-team')); ?>
            </form>

            <!-- Lista de turmas -->
            <h2><?php _e('Turmas Cadastradas', 'fight-team'); ?></h2>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th><?php _e('Nome', 'fight-team'); ?></th>
                        <th><?php _e('Professor', 'fight-team'); ?></th>
                        <th><?php _e('Horário', 'fight-team'); ?></th>
                        <th><?php _e('Dias', 'fight-team'); ?></th>
                        <th><?php _e('Alunos', 'fight-team'); ?></th>
                        <th><?php _e('Ações', 'fight-team'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($classes): ?>
                        <?php foreach ($classes as $class): ?>
                            <?php
                            $class_students = $wpdb->get_results($wpdb->prepare("
                                SELECT s.full_name 
                                FROM $table_students s 
                                JOIN $table_class_students cs ON s.id = cs.student_id 
                                WHERE cs.class_id = %d
                            ", $class->id));
                            $student_names = array_column($class_students, 'full_name');
                            ?>
                            <tr>
                                <td><?php echo esc_html($class->name); ?></td>
                                <td><?php echo esc_html($class->instructor); ?></td>
                                <td><?php echo esc_html($class->schedule); ?></td>
                                <td><?php echo esc_html($class->days_of_week); ?></td>
                                <td><?php echo esc_html(implode(', ', $student_names)); ?></td>
                                <td>
                                    <a href="<?php echo admin_url('admin.php?page=fight-team-classes&action=edit&id=' . $class->id); ?>"><?php _e('Editar', 'fight-team'); ?></a> |
                                    <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=fight-team-classes&action=delete&id=' . $class->id), 'delete_class_' . $class->id); ?>" onclick="return confirm('<?php _e('Tem certeza que deseja excluir esta turma?', 'fight-team'); ?>');"><?php _e('Excluir', 'fight-team'); ?></a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6"><?php _e('Nenhuma turma encontrada.', 'fight-team'); ?></td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php
        error_log('Fight_Team_Classes_Dashboard: Classes dashboard page rendered');
    }
}
?>