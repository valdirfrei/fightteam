<?php
// includes/class-fight-team-admin.php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class Fight_Team_Admin {
    public function __construct() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        error_log('Fight_Team_Admin: Constructor called');
    }

    public function add_admin_menu() {
        add_menu_page(
            __('Fight Team', 'fight-team'),
            __('Fight Team', 'fight-team'),
            'edit_posts',
            'fight-team',
            array($this, 'render_admin_page'),
            'dashicons-groups',
            6
        );
        add_submenu_page(
            'fight-team',
            __('Configurações', 'fight-team'),
            __('Configurações', 'fight-team'),
            'manage_options',
            'fight-team-settings',
            array($this, 'render_settings')
        );
        error_log('Fight_Team_Admin: Admin menu and settings added');
    }

    public function render_admin_page() {
        if (!current_user_can('edit_posts')) {
            wp_die(__('Sem permissão para acessar esta página.', 'fight-team'));
        }

        global $wpdb;
        $academy_name = get_option('fight_team_academy_name', 'Minha Academia');
        error_log('Fight_Team_Admin: Rendering admin page');

        if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id']) && isset($_GET['_wpnonce'])) {
            if (wp_verify_nonce($_GET['_wpnonce'], 'delete_student_' . $_GET['id'])) {
                $id = intval($_GET['id']);
                $wpdb->delete($wpdb->prefix . 'fight_team_students', array('id' => $id));
                wp_redirect(admin_url('admin.php?page=fight-team'));
                exit;
            } else {
                wp_die(__('Nonce inválido.', 'fight-team'));
            }
        }

        $students = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}fight_team_students ORDER BY full_name ASC");
        $payments = $wpdb->get_results("SELECT p.*, s.full_name FROM {$wpdb->prefix}fight_team_payments p LEFT JOIN {$wpdb->prefix}fight_team_students s ON p.student_id = s.id ORDER BY p.due_date DESC");
        
        // Buscar aniversariantes do mês
        $current_month = date('m'); // Mês atual (01 a 12)
        $birthdays = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT full_name, birth_date, DAY(birth_date) as birth_day 
                 FROM {$wpdb->prefix}fight_team_students 
                 WHERE MONTH(birth_date) = %s 
                 ORDER BY DAY(birth_date) ASC",
                $current_month
            )
        );
        ?>
        <div class="wrap">
            <h1><?php echo esc_html($academy_name); ?> - <?php _e('Fight Team Dashboard', 'fight-team'); ?></h1>
            <p><a href="https://www.vakinha.com.br/5508287" class="button button-primary" target="_blank"><?php _e('Faça uma Doação!', 'fight-team'); ?></a></p> <!-- Link de doação adicionado -->
            <h2><?php _e('Alunos', 'fight-team'); ?></h2>
            <p><a href="<?php echo admin_url('admin.php?page=fight-team-student'); ?>" class="button button-primary"><?php _e('Adicionar Novo Aluno', 'fight-team'); ?></a></p>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th><?php _e('Nome', 'fight-team'); ?></th>
                        <th><?php _e('Email', 'fight-team'); ?></th>
                        <th><?php _e('Telefone', 'fight-team'); ?></th>
                        <th><?php _e('Dia de Vencimento', 'fight-team'); ?></th>
                        <th><?php _e('Ativo', 'fight-team'); ?></th>
                        <th><?php _e('Ações', 'fight-team'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($students as $student): ?>
                        <tr>
                            <td><?php echo esc_html($student->full_name); ?></td>
                            <td><?php echo esc_html($student->email); ?></td>
                            <td><?php echo esc_html($student->phone); ?></td>
                            <td><?php echo esc_html($student->payment_due_day); ?></td>
                            <td><?php echo $student->active ? __('Sim', 'fight-team') : __('Não', 'fight-team'); ?></td>
                            <td>
                                <a href="<?php echo admin_url('admin.php?page=fight-team-student&id=' . $student->id); ?>"><?php _e('Editar', 'fight-team'); ?></a> |
                                <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=fight-team&action=delete&id=' . $student->id), 'delete_student_' . $student->id); ?>" onclick="return confirm('<?php _e('Tem certeza que deseja excluir este aluno?', 'fight-team'); ?>');"><?php _e('Excluir', 'fight-team'); ?></a> |
                                <a href="<?php echo admin_url('admin.php?page=fight-team-payments&student_id=' . $student->id); ?>"><?php _e('Adicionar Mensalidade', 'fight-team'); ?></a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <h2><?php _e('Mensalidades', 'fight-team'); ?></h2>
            <p><a href="<?php echo admin_url('admin.php?page=fight-team-payments'); ?>" class="button button-primary"><?php _e('Adicionar Nova Mensalidade', 'fight-team'); ?></a></p>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th><?php _e('Aluno', 'fight-team'); ?></th>
                        <th><?php _e('Valor', 'fight-team'); ?></th>
                        <th><?php _e('Data de Vencimento', 'fight-team'); ?></th>
                        <th><?php _e('Status', 'fight-team'); ?></th>
                        <th><?php _e('Data de Pagamento', 'fight-team'); ?></th>
                        <th><?php _e('Ações', 'fight-team'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($payments as $payment): ?>
                        <tr>
                            <td><?php echo esc_html($payment->full_name); ?></td>
                            <td><?php echo esc_html($payment->amount); ?></td>
                            <td><?php echo esc_html($payment->due_date); ?></td>
                            <td><?php echo $payment->status === 'paid' ? __('Pago', 'fight-team') : __('Pendente', 'fight-team'); ?></td>
                            <td><?php echo $payment->paid_date ? esc_html($payment->paid_date) : '-'; ?></td>
                            <td>
                                <a href="<?php echo admin_url('admin.php?page=fight-team-payments&id=' . $payment->id); ?>"><?php _e('Editar', 'fight-team'); ?></a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <h2><?php _e('Aniversariantes do Mês', 'fight-team'); ?></h2>
            <?php if (empty($birthdays)): ?>
                <p><?php _e('Nenhum aniversariante este mês.', 'fight-team'); ?></p>
            <?php else: ?>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th><?php _e('Nome', 'fight-team'); ?></th>
                            <th><?php _e('Data de Aniversário', 'fight-team'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($birthdays as $birthday): ?>
                            <tr>
                                <td><?php echo esc_html($birthday->full_name); ?></td>
                                <td><?php echo esc_html(date_i18n('d/m/Y', strtotime($birthday->birth_date))); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
        <?php
        error_log('Fight_Team_Admin: Admin page rendered');
    }

    public function render_settings() {
        if (!current_user_can('manage_options')) {
            wp_die(__('Sem permissão para acessar esta página.', 'fight-team'));
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['fight_team_settings_nonce']) && wp_verify_nonce($_POST['fight_team_settings_nonce'], 'save_settings')) {
            $academy_name = sanitize_text_field($_POST['academy_name']);
            update_option('fight_team_academy_name', $academy_name);
            echo '<div class="updated"><p>' . __('Configurações salvas.', 'fight-team') . '</p></div>';
        }

        $academy_name = get_option('fight_team_academy_name', 'Minha Academia');
        ?>
        <div class="wrap">
            <h1><?php _e('Configurações do Fight Team', 'fight-team'); ?></h1>
            <form method="post">
                <?php wp_nonce_field('save_settings', 'fight_team_settings_nonce'); ?>
                <table class="form-table">
                    <tr>
                        <th><label for="academy_name"><?php _e('Nome da Academia', 'fight-team'); ?></label></th>
                        <td>
                            <input type="text" name="academy_name" id="academy_name" value="<?php echo esc_attr($academy_name); ?>" class="regular-text">
                            <p class="description"><?php _e('Digite o nome da sua academia para exibir no dashboard e outras áreas. O nome "Fight Team" permanecerá como marca do plugin.', 'fight-team'); ?></p>
                        </td>
                    </tr>
                </table>
                <?php submit_button(__('Salvar Configurações', 'fight-team')); ?>
            </form>
        </div>
        <?php
        error_log('Fight_Team_Admin: Settings page rendered');
    }
}
?>