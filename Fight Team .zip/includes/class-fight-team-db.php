<?php
// includes/class-fight-team-db.php
class Fight_Team_DB {
    private $table_students;
    private $table_payments;
    private $table_attendances;
    private $table_classes;
    private $table_student_classes;

    public function __construct() {
        global $wpdb;
        $this->table_students = $wpdb->prefix . 'fight_team_students';
        $this->table_payments = $wpdb->prefix . 'fight_team_payments';
        $this->table_attendances = $wpdb->prefix . 'fight_team_attendances';
        $this->table_classes = $wpdb->prefix . 'fight_team_classes';
        $this->table_student_classes = $wpdb->prefix . 'fight_team_student_classes';
    }

    public function create_tables() {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();

        // Tabela de alunos
        $sql_students = "CREATE TABLE $this->table_students (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            full_name varchar(255) NOT NULL,
            birth_date date NOT NULL,
            address text NOT NULL,
            phone varchar(20) NOT NULL,
            email varchar(100) NOT NULL,
            city varchar(100) NOT NULL,
            state varchar(100) NOT NULL,
            zip_code varchar(20) NOT NULL,
            belt_level varchar(50) DEFAULT NULL,
            start_date date DEFAULT NULL,
            exam_dates text DEFAULT NULL,
            guardian varchar(255) DEFAULT NULL,
            guardian_phone varchar(20) DEFAULT NULL,
            medical_info text DEFAULT NULL,
            rg varchar(20) DEFAULT NULL,
            cpf varchar(14) DEFAULT NULL,
            photo_url varchar(255) DEFAULT NULL,
            payment_due_day int(2) DEFAULT NULL,
            weight decimal(5,2) DEFAULT NULL,
            height decimal(3,2) DEFAULT NULL,
            international_membership varchar(20) NOT NULL,
            brazilian_confederation varchar(20) NOT NULL,
            federation varchar(20) NOT NULL,
            active tinyint(1) NOT NULL DEFAULT 1,
            user_id bigint(20) DEFAULT 0 NOT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $charset_collate;";

        // Tabela de mensalidades
        $sql_payments = "CREATE TABLE $this->table_payments (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            student_id bigint(20) NOT NULL,
            amount decimal(10,2) NOT NULL,
            due_date date NOT NULL,
            status varchar(20) NOT NULL DEFAULT 'pending',
            paid_date date DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            FOREIGN KEY (student_id) REFERENCES $this->table_students(id) ON DELETE CASCADE
        ) $charset_collate;";

        // Tabela de presenças
        $sql_attendances = "CREATE TABLE $this->table_attendances (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            student_id bigint(20) NOT NULL,
            class_id bigint(20) NOT NULL,
            attendance_date date NOT NULL,
            present tinyint(1) NOT NULL DEFAULT 0,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            FOREIGN KEY (student_id) REFERENCES $this->table_students(id) ON DELETE CASCADE,
            FOREIGN KEY (class_id) REFERENCES $this->table_classes(id) ON DELETE CASCADE
        ) $charset_collate;";

        // Tabela de turmas
        $sql_classes = "CREATE TABLE $this->table_classes (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            name varchar(100) NOT NULL,
            schedule varchar(100) NOT NULL,
            instructor varchar(255) NOT NULL,
            days_of_week text DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $charset_collate;";

        // Tabela de relacionamento aluno-turma
        $sql_student_classes = "CREATE TABLE $this->table_student_classes (
            student_id bigint(20) NOT NULL,
            class_id bigint(20) NOT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (student_id, class_id),
            FOREIGN KEY (student_id) REFERENCES $this->table_students(id) ON DELETE CASCADE,
            FOREIGN KEY (class_id) REFERENCES $this->table_classes(id) ON DELETE CASCADE
        ) $charset_collate;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql_students);
        dbDelta($sql_payments);
        dbDelta($sql_attendances);
        dbDelta($sql_classes);
        dbDelta($sql_student_classes);
    }
}
?>