<?php
// includes/class-fight-team-backup.php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class Fight_Team_Backup {
    public function __construct() {
        add_action('admin_menu', array($this, 'add_backup_menu'));
        add_action('admin_init', array($this, 'handle_export_csv'));
        add_action('admin_init', array($this, 'handle_import_csv'));
        error_log('Fight_Team_Backup: Constructor called');
    }

    public function add_backup_menu() {
        add_submenu_page(
            'fight-team',
            __('Backup de Alunos', 'fight-team'),
            __('Backup de Alunos', 'fight-team'),
            'manage_options',
            'fight-team-backup',
            array($this, 'render_backup_page')
        );
        error_log('Fight_Team_Backup: Backup menu added');
    }

    public function render_backup_page() {
        if (!current_user_can('manage_options')) {
            wp_die(__('Sem permissão para acessar esta página.', 'fight-team'));
        }

        $academy_name = get_option('fight_team_academy_name', 'Minha Academia');
        error_log('Fight_Team_Backup: Rendering backup page');
        ?>
        <div class="wrap">
            <h1><?php echo esc_html($academy_name); ?> - <?php _e('Backup de Alunos', 'fight-team'); ?></h1>
            
            <h2><?php _e('Exportar Dados', 'fight-team'); ?></h2>
            <p><?php _e('Clique no botão abaixo para exportar todos os dados dos alunos em formato CSV, compatível com Excel.', 'fight-team'); ?></p>
            <form method="post">
                <?php wp_nonce_field('export_students_csv', 'export_csv_nonce'); ?>
                <input type="hidden" name="action" value="export_students_csv">
                <?php submit_button(__('Exportar para CSV', 'fight-team'), 'primary'); ?>
            </form>

            <h2><?php _e('Importar Dados', 'fight-team'); ?></h2>
            <p><?php _e('Faça upload de um arquivo CSV para importar os dados dos alunos. O arquivo deve seguir o mesmo formato do exportado.', 'fight-team'); ?></p>
            <?php if (isset($_GET['import_result'])): ?>
                <div class="<?php echo esc_attr($_GET['import_result'] === 'success' ? 'updated' : 'error'); ?>">
                    <p><?php echo esc_html($_GET['import_message']); ?></p>
                </div>
            <?php endif; ?>
            <form method="post" enctype="multipart/form-data">
                <?php wp_nonce_field('import_students_csv', 'import_csv_nonce'); ?>
                <input type="hidden" name="action" value="import_students_csv">
                <p>
                    <label for="csv_file"><?php _e('Selecione o arquivo CSV:', 'fight-team'); ?></label><br>
                    <input type="file" name="csv_file" id="csv_file" accept=".csv" required>
                </p>
                <?php submit_button(__('Importar CSV', 'fight-team'), 'secondary'); ?>
            </form>
        </div>
        <?php
        error_log('Fight_Team_Backup: Backup page rendered');
    }

    public function handle_export_csv() {
        if (isset($_POST['action']) && $_POST['action'] === 'export_students_csv' && isset($_POST['export_csv_nonce']) && wp_verify_nonce($_POST['export_csv_nonce'], 'export_students_csv')) {
            if (!current_user_can('manage_options')) {
                wp_die(__('Sem permissão para realizar esta ação.', 'fight-team'));
            }

            global $wpdb;
            $students = $wpdb->get_results("
                SELECT s.*, p.status AS payment_status, p.due_date AS payment_due_date, p.paid_date AS payment_paid_date
                FROM {$wpdb->prefix}fight_team_students s
                LEFT JOIN {$wpdb->prefix}fight_team_payments p ON s.id = p.student_id
                AND p.due_date = (SELECT MAX(due_date) FROM {$wpdb->prefix}fight_team_payments WHERE student_id = s.id)
                ORDER BY s.full_name ASC
            ");

            // Definir cabeçalhos do CSV
            $filename = 'fight-team-students-backup-' . date('Y-m-d-H-i-s') . '.csv';
            header('Content-Type: text/csv; charset=utf-8');
            header('Content-Disposition: attachment; filename="' . $filename . '"');

            // Adicionar BOM para UTF-8 (garante compatibilidade com Excel)
            echo "\xEF\xBB\xBF";

            // Abrir saída para o CSV
            $output = fopen('php://output', 'w');

            // Cabeçalhos da tabela
            $headers = [
                __('ID', 'fight-team'),
                __('Nome Completo', 'fight-team'),
                __('Data de Nascimento', 'fight-team'),
                __('Idade', 'fight-team'),
                __('Endereço', 'fight-team'),
                __('Telefone', 'fight-team'),
                __('Email', 'fight-team'),
                __('Cidade', 'fight-team'),
                __('Estado', 'fight-team'),
                __('CEP', 'fight-team'),
                __('Nível da Faixa', 'fight-team'),
                __('Data de Início', 'fight-team'),
                __('Tempo de Treino', 'fight-team'),
                __('Datas de Exame', 'fight-team'),
                __('Responsável', 'fight-team'),
                __('Telefone do Responsável', 'fight-team'),
                __('Informações Médicas', 'fight-team'),
                __('RG', 'fight-team'),
                __('CPF', 'fight-team'),
                __('URL da Foto', 'fight-team'),
                __('Dia de Vencimento', 'fight-team'),
                __('Peso', 'fight-team'),
                __('Altura', 'fight-team'),
                __('Membro Internacional', 'fight-team'),
                __('Confederação Brasileira', 'fight-team'),
                __('Federação', 'fight-team'),
                __('Ativo', 'fight-team'),
                __('ID do Usuário', 'fight-team'),
                __('Data de Criação', 'fight-team'),
                __('Status da Última Mensalidade', 'fight-team'),
                __('Data de Vencimento da Última Mensalidade', 'fight-team'),
                __('Data de Pagamento da Última Mensalidade', 'fight-team'),
            ];
            fputcsv($output, $headers);

            // Dados dos alunos
            foreach ($students as $student) {
                $birth_date = $student->birth_date ? new DateTime($student->birth_date) : null;
                $today = new DateTime();
                $age = $birth_date ? $today->diff($birth_date)->y . ' anos' : '-';

                $start_date = $student->start_date ? new DateTime($student->start_date) : null;
                $training_time = '-';
                if ($start_date) {
                    $interval = $today->diff($start_date);
                    $training_time = sprintf('%d anos, %d meses', $interval->y, $interval->m);
                }

                $status = $student->payment_status ? ($student->payment_status === 'paid' ? __('Pago', 'fight-team') : __('Pendente', 'fight-team')) : '-';

                $row = [
                    $student->id,
                    $student->full_name,
                    $student->birth_date ? date_i18n('d/m/Y', strtotime($student->birth_date)) : '',
                    $age,
                    $student->address,
                    $student->phone,
                    $student->email,
                    $student->city,
                    $student->state,
                    $student->zip_code,
                    $student->belt_level ?: '',
                    $student->start_date ? date_i18n('d/m/Y', strtotime($student->start_date)) : '',
                    $training_time,
                    $student->exam_dates ?: '',
                    $student->guardian ?: '',
                    $student->guardian_phone ?: '',
                    $student->medical_info ?: '',
                    $student->rg ?: '',
                    $student->cpf ?: '',
                    $student->photo_url ?: '',
                    $student->payment_due_day ? sprintf('%02d', $student->payment_due_day) : '',
                    $student->weight ? $student->weight . ' kg' : '',
                    $student->height ? $student->height . ' m' : '',
                    $student->international_membership,
                    $student->brazilian_confederation,
                    $student->federation,
                    $student->active ? __('Sim', 'fight-team') : __('Não', 'fight-team'),
                    $student->user_id,
                    $student->created_at ? date_i18n('d/m/Y H:i:s', strtotime($student->created_at)) : '',
                    $status,
                    $student->payment_due_date ? date_i18n('d/m/Y', strtotime($student->payment_due_date)) : '',
                    $student->payment_paid_date ? date_i18n('d/m/Y', strtotime($student->payment_paid_date)) : '',
                ];
                fputcsv($output, $row);
            }

            fclose($output);
            exit;
        }
    }

    public function handle_import_csv() {
        if (isset($_POST['action']) && $_POST['action'] === 'import_students_csv' && isset($_POST['import_csv_nonce']) && wp_verify_nonce($_POST['import_csv_nonce'], 'import_students_csv')) {
            if (!current_user_can('manage_options')) {
                wp_die(__('Sem permissão para realizar esta ação.', 'fight-team'));
            }

            if (!isset($_FILES['csv_file']) || $_FILES['csv_file']['error'] !== UPLOAD_ERR_OK) {
                wp_redirect(add_query_arg(['import_result' => 'error', 'import_message' => __('Erro ao fazer upload do arquivo.', 'fight-team')], admin_url('admin.php?page=fight-team-backup')));
                exit;
            }

            global $wpdb;
            $file = $_FILES['csv_file']['tmp_name'];
            $handle = fopen($file, 'r');

            if (!$handle) {
                wp_redirect(add_query_arg(['import_result' => 'error', 'import_message' => __('Erro ao abrir o arquivo CSV.', 'fight-team')], admin_url('admin.php?page=fight-team-backup')));
                exit;
            }

            // Ler cabeçalhos
            $headers = fgetcsv($handle);
            $expected_headers = [
                __('ID', 'fight-team'),
                __('Nome Completo', 'fight-team'),
                __('Data de Nascimento', 'fight-team'),
                __('Idade', 'fight-team'),
                __('Endereço', 'fight-team'),
                __('Telefone', 'fight-team'),
                __('Email', 'fight-team'),
                __('Cidade', 'fight-team'),
                __('Estado', 'fight-team'),
                __('CEP', 'fight-team'),
                __('Nível da Faixa', 'fight-team'),
                __('Data de Início', 'fight-team'),
                __('Tempo de Treino', 'fight-team'),
                __('Datas de Exame', 'fight-team'),
                __('Responsável', 'fight-team'),
                __('Telefone do Responsável', 'fight-team'),
                __('Informações Médicas', 'fight-team'),
                __('RG', 'fight-team'),
                __('CPF', 'fight-team'),
                __('URL da Foto', 'fight-team'),
                __('Dia de Vencimento', 'fight-team'),
                __('Peso', 'fight-team'),
                __('Altura', 'fight-team'),
                __('Membro Internacional', 'fight-team'),
                __('Confederação Brasileira', 'fight-team'),
                __('Federação', 'fight-team'),
                __('Ativo', 'fight-team'),
                __('ID do Usuário', 'fight-team'),
                __('Data de Criação', 'fight-team'),
                __('Status da Última Mensalidade', 'fight-team'),
                __('Data de Vencimento da Última Mensalidade', 'fight-team'),
                __('Data de Pagamento da Última Mensalidade', 'fight-team'),
            ];

            if ($headers !== $expected_headers) {
                fclose($handle);
                wp_redirect(add_query_arg(['import_result' => 'error', 'import_message' => __('Formato de CSV inválido. Verifique os cabeçalhos.', 'fight-team')], admin_url('admin.php?page=fight-team-backup')));
                exit;
            }

            $success_count = 0;
            $error_count = 0;

            while (($data = fgetcsv($handle)) !== false) {
                // Mapear dados para colunas
                $student_data = [
                    'id' => intval($data[0]),
                    'full_name' => sanitize_text_field($data[1]),
                    'birth_date' => $data[2] ? date('Y-m-d', strtotime(str_replace('/', '-', $data[2]))) : null,
                    'address' => sanitize_textarea_field($data[4]),
                    'phone' => sanitize_text_field($data[5]),
                    'email' => sanitize_email($data[6]),
                    'city' => sanitize_text_field($data[7]),
                    'state' => sanitize_text_field($data[8]),
                    'zip_code' => sanitize_text_field($data[9]),
                    'belt_level' => sanitize_text_field($data[10]),
                    'start_date' => $data[11] ? date('Y-m-d', strtotime(str_replace('/', '-', $data[11]))) : null,
                    'exam_dates' => sanitize_textarea_field($data[13]),
                    'guardian' => sanitize_text_field($data[14]),
                    'guardian_phone' => sanitize_text_field($data[15]),
                    'medical_info' => sanitize_textarea_field($data[16]),
                    'rg' => sanitize_text_field($data[17]),
                    'cpf' => sanitize_text_field($data[18]),
                    'photo_url' => esc_url_raw($data[19]),
                    'payment_due_day' => intval($data[20]),
                    'weight' => floatval(str_replace(' kg', '', $data[21])),
                    'height' => floatval(str_replace(' m', '', $data[22])),
                    'international_membership' => sanitize_text_field($data[23]),
                    'brazilian_confederation' => sanitize_text_field($data[24]),
                    'federation' => sanitize_text_field($data[25]),
                    'active' => $data[26] === __('Sim', 'fight-team') ? 1 : 0,
                    'user_id' => intval($data[27]),
                    'created_at' => $data[28] ? date('Y-m-d H:i:s', strtotime(str_replace('/', '-', $data[28]))) : current_time('mysql'),
                ];

                // Validar campos obrigatórios
                if (empty($student_data['full_name']) || empty($student_data['birth_date']) || empty($student_data['address']) || 
                    empty($student_data['phone']) || empty($student_data['email']) || empty($student_data['city']) || 
                    empty($student_data['state']) || empty($student_data['zip_code']) || empty($student_data['international_membership']) || 
                    empty($student_data['brazilian_confederation']) || empty($student_data['federation'])) {
                    $error_count++;
                    continue;
                }

                // Verificar se o aluno já existe (por ID ou CPF)
                $existing_student = $student_data['id'] ? $wpdb->get_row($wpdb->prepare("SELECT id FROM {$wpdb->prefix}fight_team_students WHERE id = %d", $student_data['id'])) : null;
                if (!$existing_student && $student_data['cpf']) {
                    $existing_student = $wpdb->get_row($wpdb->prepare("SELECT id FROM {$wpdb->prefix}fight_team_students WHERE cpf = %s", $student_data['cpf']));
                }

                if ($existing_student) {
                    // Atualizar aluno existente
                    $wpdb->update(
                        $wpdb->prefix . 'fight_team_students',
                        $student_data,
                        ['id' => $existing_student->id],
                        ['%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%f', '%f', '%s', '%s', '%s', '%d', '%d', '%s'],
                        ['%d']
                    );
                    $student_id = $existing_student->id;
                } else {
                    // Inserir novo aluno
                    $wpdb->insert(
                        $wpdb->prefix . 'fight_team_students',
                        $student_data,
                        ['%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%f', '%f', '%s', '%s', '%s', '%d', '%d', '%s']
                    );
                    $student_id = $wpdb->insert_id;
                }

                // Processar dados de pagamento, se existirem
                $payment_status = $data[29];
                $payment_due_date = $data[30] ? date('Y-m-d', strtotime(str_replace('/', '-', $data[30]))) : null;
                $payment_paid_date = $data[31] ? date('Y-m-d', strtotime(str_replace('/', '-', $data[31]))) : null;

                if ($student_id && $payment_status && $payment_due_date) {
                    $payment_data = [
                        'student_id' => $student_id,
                        'amount' => 0.00, // Valor padrão (pode ser ajustado se necessário)
                        'due_date' => $payment_due_date,
                        'status' => $payment_status === __('Pago', 'fight-team') ? 'paid' : 'pending',
                        'paid_date' => $payment_paid_date,
                        'created_at' => current_time('mysql'),
                    ];

                    $existing_payment = $wpdb->get_row($wpdb->prepare(
                        "SELECT id FROM {$wpdb->prefix}fight_team_payments WHERE student_id = %d AND due_date = %s",
                        $student_id, $payment_due_date
                    ));

                    if ($existing_payment) {
                        $wpdb->update(
                            $wpdb->prefix . 'fight_team_payments',
                            $payment_data,
                            ['id' => $existing_payment->id],
                            ['%d', '%f', '%s', '%s', '%s', '%s'],
                            ['%d']
                        );
                    } else {
                        $wpdb->insert(
                            $wpdb->prefix . 'fight_team_payments',
                            $payment_data,
                            ['%d', '%f', '%s', '%s', '%s', '%s']
                        );
                    }
                }

                $success_count++;
            }

            fclose($handle);

            $message = sprintf(
                __('Importação concluída: %d registros importados com sucesso, %d erros.', 'fight-team'),
                $success_count,
                $error_count
            );
            wp_redirect(add_query_arg(['import_result' => 'success', 'import_message' => $message], admin_url('admin.php?page=fight-team-backup')));
            exit;
        }
    }
}
?>