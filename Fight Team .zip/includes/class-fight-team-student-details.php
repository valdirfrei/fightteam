<?php
// includes/class-fight-team-student-details.php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class Fight_Team_Student_Details {
    public function __construct() {
        add_action('admin_menu', array($this, 'add_student_details_menu'));
        add_action('wp_ajax_get_student_details', array($this, 'get_student_details'));
        error_log('Fight_Team_Student_Details: Constructor called');
    }

    public function add_student_details_menu() {
        add_submenu_page(
            'fight-team',
            __('Detalhes do Aluno', 'fight-team'),
            __('Detalhes do Aluno', 'fight-team'),
            'edit_posts',
            'fight-team-student-details',
            array($this, 'render_student_details_page')
        );
        error_log('Fight_Team_Student_Details: Student details menu added');
    }

    public function render_student_details_page() {
        if (!current_user_can('edit_posts')) {
            wp_die(__('Sem permissão para acessar esta página.', 'fight-team'));
        }

        global $wpdb;
        $academy_name = get_option('fight_team_academy_name', 'Minha Academia');
        $students = $wpdb->get_results("SELECT id, full_name FROM {$wpdb->prefix}fight_team_students ORDER BY full_name ASC");
        error_log('Fight_Team_Student_Details: Rendering student details page');
        ?>
        <div class="wrap">
            <h1><?php echo esc_html($academy_name); ?> - <?php _e('Detalhes do Aluno', 'fight-team'); ?></h1>
            <div class="form-group">
                <label for="student_select"><?php _e('Selecione o Aluno', 'fight-team'); ?></label>
                <select id="student_select" name="student_select" class="regular-text">
                    <option value=""><?php _e('Escolha um aluno', 'fight-team'); ?></option>
                    <?php foreach ($students as $student): ?>
                        <option value="<?php echo esc_attr($student->id); ?>"><?php echo esc_html($student->full_name); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div id="student_details" style="margin-top: 20px;">
                <table class="wp-list-table widefat fixed striped" style="display: none;">
                    <tbody>
                        <tr>
                            <td colspan="4"><strong><?php _e('Nome', 'fight-team'); ?>:</strong> <span id="full_name"></span></td>
                        </tr>
                        <tr>
                            <td><strong><?php _e('Data de Nascimento', 'fight-team'); ?>:</strong></td>
                            <td id="birth_date"></td>
                            <td><strong><?php _e('Idade', 'fight-team'); ?>:</strong></td>
                            <td id="age"></td>
                        </tr>
                        <tr>
                            <td><strong><?php _e('Faixa', 'fight-team'); ?>:</strong></td>
                            <td id="belt_level"></td>
                            <td><strong><?php _e('Tempo de Treino', 'fight-team'); ?>:</strong></td>
                            <td id="training_time"></td>
                        </tr>
                        <tr>
                            <td><strong><?php _e('Peso', 'fight-team'); ?>:</strong></td>
                            <td id="weight"></td>
                            <td><strong><?php _e('Altura', 'fight-team'); ?>:</strong></td>
                            <td id="height"></td>
                        </tr>
                        <tr>
                            <td><strong><?php _e('Data de Vencimento', 'fight-team'); ?>:</strong></td>
                            <td id="payment_due_day"></td>
                            <td><strong><?php _e('Mensalidade', 'fight-team'); ?>:</strong></td>
                            <td id="status"></td>
                        </tr>
                        <tr>
                            <td><strong><?php _e('Confederação', 'fight-team'); ?>:</strong></td>
                            <td id="brazilian_confederation"></td>
                            <td><strong><?php _e('Federação', 'fight-team'); ?>:</strong></td>
                            <td id="federation"></td>
                        </tr>
                        <tr>
                            <td><strong><?php _e('Telefone', 'fight-team'); ?>:</strong></td>
                            <td id="phone"></td>
                            <td><strong><?php _e('Datas de Exames', 'fight-team'); ?>:</strong></td> <!-- Novo campo -->
                            <td id="exam_dates"></td> <!-- Novo campo -->
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <script>
            jQuery(document).ready(function($) {
                $('#student_select').on('change', function() {
                    var student_id = $(this).val();
                    if (student_id) {
                        $.ajax({
                            url: ajaxurl,
                            type: 'POST',
                            data: {
                                action: 'get_student_details',
                                student_id: student_id
                            },
                            success: function(response) {
                                if (response.success) {
                                    $('#full_name').text(response.data.full_name || '-');
                                    $('#birth_date').text(response.data.birth_date || '-');
                                    $('#age').text(response.data.age || '-');
                                    $('#belt_level').text(response.data.belt_level || '-');
                                    $('#training_time').text(response.data.training_time || '-');
                                    $('#weight').text(response.data.weight ? response.data.weight + ' kg' : '-');
                                    $('#height').text(response.data.height ? response.data.height + ' m' : '-');
                                    $('#payment_due_day').text(response.data.payment_due_day || '-');
                                    $('#status').text(response.data.status || '-');
                                    $('#brazilian_confederation').text(response.data.brazilian_confederation || '-');
                                    $('#federation').text(response.data.federation || '-');
                                    $('#phone').text(response.data.phone || '-');
                                    $('#exam_dates').text(response.data.exam_dates || '-'); // Novo campo
                                    $('#student_details table').show();
                                } else {
                                    $('#student_details table').hide();
                                    alert('Erro ao carregar os detalhes do aluno.');
                                }
                            },
                            error: function() {
                                $('#student_details table').hide();
                                alert('Erro ao conectar com o servidor.');
                            }
                        });
                    } else {
                        $('#student_details table').hide();
                    }
                });
            });
        </script>
        <?php
        error_log('Fight_Team_Student_Details: Student details page rendered');
    }

    public function get_student_details() {
        check_ajax_referer('wp_ajax_get_student_details', 'security', false);

        global $wpdb;
        $student_id = isset($_POST['student_id']) ? intval($_POST['student_id']) : 0;

        if (!$student_id) {
            wp_send_json_error('ID do aluno inválido.');
        }

        $student = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}fight_team_students WHERE id = %d", $student_id));
        $latest_payment = $wpdb->get_row($wpdb->prepare("SELECT status FROM {$wpdb->prefix}fight_team_payments WHERE student_id = %d ORDER BY due_date DESC LIMIT 1", $student_id));

        if ($student) {
            $birth_date = new DateTime($student->birth_date);
            $today = new DateTime();
            $age = $today->diff($birth_date)->y;

            $start_date = $student->start_date ? new DateTime($student->start_date) : null;
            $training_time = '-';
            if ($start_date) {
                $interval = $today->diff($start_date);
                $training_time = sprintf('%d anos, %d meses', $interval->y, $interval->m);
            }

            $status = $latest_payment ? ($latest_payment->status === 'paid' ? __('Pago', 'fight-team') : __('Pendente', 'fight-team')) : '-';

            wp_send_json_success([
                'full_name' => $student->full_name,
                'birth_date' => $student->birth_date ? date_i18n('d/m/Y', strtotime($student->birth_date)) : '-',
                'age' => $age ? $age . ' anos' : '-',
                'belt_level' => $student->belt_level ?: '-',
                'training_time' => $training_time,
                'weight' => $student->weight ?: null,
                'height' => $student->height ?: null,
                'payment_due_day' => $student->payment_due_day ? sprintf('%02d', $student->payment_due_day) : '-',
                'status' => $status,
                'brazilian_confederation' => $student->brazilian_confederation ?: '-',
                'federation' => $student->federation ?: '-',
                'phone' => $student->phone ?: '-',
                'exam_dates' => $student->exam_dates ?: '-' // Novo campo, tratado como texto puro
            ]);
        } else {
            wp_send_json_error('Aluno não encontrado.');
        }
    }
}
?>