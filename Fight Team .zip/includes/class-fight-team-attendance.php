<?php
// includes/class-fight-team-attendance.php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class Fight_Team_Attendance {
    public function __construct() {
        add_action('admin_menu', array($this, 'add_attendance_menu'));
        add_action('wp_ajax_mark_attendance', array($this, 'mark_attendance'));
        error_log('Fight_Team_Attendance: Constructor called');
    }

    public function add_attendance_menu() {
        add_submenu_page(
            'fight-team',
            __('Registro de Presenças', 'fight-team'),
            __('Presenças', 'fight-team'),
            'edit_posts',
            'fight-team-attendance',
            array($this, 'render_attendance_page')
        );
        error_log('Fight_Team_Attendance: Attendance menu added');
    }

    public function render_attendance_page() {
        if (!current_user_can('edit_posts')) {
            wp_die(__('Sem permissão para acessar esta página.', 'fight-team'));
        }

        global $wpdb;
        $academy_name = get_option('fight_team_academy_name', 'Minha Academia');
        $classes = $wpdb->get_results("SELECT id, name FROM {$wpdb->prefix}fight_team_classes ORDER BY name ASC");
        $selected_class_id = isset($_GET['class_id']) ? intval($_GET['class_id']) : 0;
        $selected_date = isset($_GET['attendance_date']) ? sanitize_text_field($_GET['attendance_date']) : date('Y-m-d');

        error_log('Fight_Team_Attendance: Rendering attendance page');
        ?>
        <div class="wrap">
            <h1><?php echo esc_html($academy_name); ?> - <?php _e('Registro de Presenças', 'fight-team'); ?></h1>
            <form method="get">
                <input type="hidden" name="page" value="fight-team-attendance">
                <div class="form-group">
                    <label for="class_id"><?php _e('Selecione a Turma', 'fight-team'); ?></label>
                    <select id="class_id" name="class_id" class="regular-text" required>
                        <option value=""><?php _e('Escolha uma turma', 'fight-team'); ?></option>
                        <?php foreach ($classes as $class): ?>
                            <option value="<?php echo esc_attr($class->id); ?>" <?php selected($selected_class_id, $class->id); ?>>
                                <?php echo esc_html($class->name); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="attendance_date"><?php _e('Data da Presença', 'fight-team'); ?></label>
                    <input type="date" id="attendance_date" name="attendance_date" value="<?php echo esc_attr($selected_date); ?>" required>
                </div>
                <?php submit_button(__('Filtrar', 'fight-team'), 'secondary'); ?>
            </form>

            <?php if ($selected_class_id && $selected_date): ?>
                <?php
                $students = $wpdb->get_results($wpdb->prepare("
                    SELECT s.id, s.full_name, a.present
                    FROM {$wpdb->prefix}fight_team_students s
                    LEFT JOIN {$wpdb->prefix}fight_team_attendances a ON s.id = a.student_id 
                        AND a.class_id = %d AND a.attendance_date = %s
                    WHERE s.active = 1
                    ORDER BY s.full_name ASC
                ", $selected_class_id, $selected_date));
                ?>
                <h2><?php _e('Alunos', 'fight-team'); ?></h2>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th><?php _e('Nome', 'fight-team'); ?></th>
                            <th><?php _e('Presença', 'fight-team'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($students as $student): ?>
                            <tr>
                                <td><?php echo esc_html($student->full_name); ?></td>
                                <td>
                                    <button class="button <?php echo $student->present === '1' ? 'button-primary' : ''; ?>" 
                                            onclick="markAttendance(<?php echo esc_attr($student->id); ?>, <?php echo esc_attr($selected_class_id); ?>, '<?php echo esc_attr($selected_date); ?>', 1)">
                                        <?php _e('Presente', 'fight-team'); ?>
                                    </button>
                                    <button class="button <?php echo $student->present === '0' ? 'button-secondary' : ''; ?>" 
                                            onclick="markAttendance(<?php echo esc_attr($student->id); ?>, <?php echo esc_attr($selected_class_id); ?>, '<?php echo esc_attr($selected_date); ?>', 0)">
                                        <?php _e('Faltou', 'fight-team'); ?>
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
        <script>
            function markAttendance(studentId, classId, date, present) {
                jQuery.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'mark_attendance',
                        student_id: studentId,
                        class_id: classId,
                        attendance_date: date,
                        present: present,
                        nonce: '<?php echo wp_create_nonce('mark_attendance_nonce'); ?>'
                    },
                    success: function(response) {
                        if (response.success) {
                            // Atualizar botões
                            var buttons = jQuery('button[onclick*="markAttendance(' + studentId + ',' + classId + ',\'' + date + '\'"]');
                            buttons.removeClass('button-primary button-secondary');
                            if (present) {
                                buttons.eq(0).addClass('button-primary');
                                buttons.eq(1).addClass('button-secondary');
                            } else {
                                buttons.eq(0).addClass('button-secondary');
                                buttons.eq(1).addClass('button-primary');
                            }
                        } else {
                            alert('Erro: ' + response.data);
                        }
                    },
                    error: function() {
                        alert('<?php _e('Erro ao conectar com o servidor.', 'fight-team'); ?>');
                    }
                });
            }
        </script>
        <?php
        error_log('Fight_Team_Attendance: Attendance page rendered');
    }

    public function mark_attendance() {
        check_ajax_referer('mark_attendance_nonce', 'nonce');

        if (!current_user_can('edit_posts')) {
            wp_send_json_error(__('Sem permissão para realizar esta ação.', 'fight-team'));
        }

        global $wpdb;
        $student_id = isset($_POST['student_id']) ? intval($_POST['student_id']) : 0;
        $class_id = isset($_POST['class_id']) ? intval($_POST['class_id']) : 0;
        $attendance_date = isset($_POST['attendance_date']) ? sanitize_text_field($_POST['attendance_date']) : '';
        $present = isset($_POST['present']) ? intval($_POST['present']) : 0;

        if (!$student_id || !$class_id || !$attendance_date) {
            wp_send_json_error(__('Dados inválidos.', 'fight-team'));
        }

        // Verificar se já existe registro de presença
        $existing = $wpdb->get_row($wpdb->prepare("
            SELECT id FROM {$wpdb->prefix}fight_team_attendances
            WHERE student_id = %d AND class_id = %d AND attendance_date = %s
        ", $student_id, $class_id, $attendance_date));

        if ($existing) {
            // Atualizar registro existente
            $wpdb->update(
                $wpdb->prefix . 'fight_team_attendances',
                ['present' => $present, 'created_at' => current_time('mysql')],
                ['id' => $existing->id],
                ['%d', '%s'],
                ['%d']
            );
        } else {
            // Inserir novo registro
            $wpdb->insert(
                $wpdb->prefix . 'fight_team_attendances',
                [
                    'student_id' => $student_id,
                    'class_id' => $class_id,
                    'attendance_date' => $attendance_date,
                    'present' => $present,
                    'created_at' => current_time('mysql'),
                ],
                ['%d', '%d', '%s', '%d', '%s']
            );
        }

        if ($wpdb->last_error) {
            wp_send_json_error(__('Erro ao salvar a presença.', 'fight-team'));
        }

        wp_send_json_success();
    }
}
?>