<?php
// includes/class-fight-team-students-dashboard.php
if (!defined('ABSPATH')) {
    exit; // Prevenir acesso direto
}

class Fight_Team_Students_Dashboard {
    public function __construct() {
        add_shortcode('fight_team_students_dashboard', array($this, 'render_students_dashboard_shortcode'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        error_log('Fight_Team_Students_Dashboard: Constructor called');
    }

    public function enqueue_scripts() {
        // Carregar apenas se o shortcode estiver presente
        global $post;
        if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'fight_team_students_dashboard')) {
            if (!defined('FT_PLUGIN_URL')) {
                error_log('Fight_Team_Students_Dashboard: FT_PLUGIN_URL not defined');
                return;
            }
            wp_enqueue_style('fight-team-shortcode', FT_PLUGIN_URL . 'assets/css/admin.css', array(), '2.0');
            error_log('Fight_Team_Students_Dashboard: Styles enqueued');
        }
    }

    public function render_students_dashboard_shortcode($atts) {
        global $wpdb;
        error_log('Fight_Team_Students_Dashboard: Rendering students dashboard shortcode');

        // Verificar permissões
        if (!current_user_can('manage_options')) {
            error_log('Fight_Team_Students_Dashboard: User lacks manage_options permission');
            return '<p>' . __('Você não tem permissão para acessar esta área.', 'fight-team') . '</p>';
        }

        // Verificar se as tabelas existem
        $classes_table = $wpdb->prefix . 'fight_team_classes';
        $tables_exist = $wpdb->get_var("SHOW TABLES LIKE '$classes_table'") === $classes_table;
        if (!$tables_exist) {
            error_log('Fight_Team_Students_Dashboard: Table ' . $classes_table . ' does not exist');
            return '<p>' . __('Erro: Tabela de turmas não encontrada. Contate o administrador.', 'fight-team') . '</p>';
        }

        // Obter todas as turmas
        $classes = $wpdb->get_results("SELECT id, name, schedule FROM $classes_table");
        if ($wpdb->last_error) {
            error_log('Fight_Team_Students_Dashboard: Database error fetching classes: ' . $wpdb->last_error);
            return '<p>' . __('Erro ao carregar turmas. Contate o administrador.', 'fight-team') . '</p>';
        }

        $selected_class_id = isset($_GET['class_id']) ? intval($_GET['class_id']) : 0;

        // Obter alunos da turma selecionada
        $students = array();
        if ($selected_class_id) {
            $students_table = $wpdb->prefix . 'fight_team_students';
            $student_classes_table = $wpdb->prefix . 'fight_team_student_classes';
            $payments_table = $wpdb->prefix . 'fight_team_payments';

            // Verificar se as tabelas necessárias existem
            $students_table_exists = $wpdb->get_var("SHOW TABLES LIKE '$students_table'") === $students_table;
            $student_classes_table_exists = $wpdb->get_var("SHOW TABLES LIKE '$student_classes_table'") === $student_classes_table;
            $payments_table_exists = $wpdb->get_var("SHOW TABLES LIKE '$payments_table'") === $payments_table;

            if (!$students_table_exists || !$student_classes_table_exists || !$payments_table_exists) {
                error_log('Fight_Team_Students_Dashboard: One or more required tables are missing');
                return '<p>' . __('Erro: Uma ou mais tabelas necessárias não foram encontradas.', 'fight-team') . '</p>';
            }

            $students = $wpdb->get_results($wpdb->prepare(
                "SELECT s.id, s.full_name, s.phone, s.belt_level, s.exam_dates
                 FROM $students_table s
                 JOIN $student_classes_table sc ON s.id = sc.student_id
                 WHERE sc.class_id = %d AND s.active = 1",
                $selected_class_id
            ));

            if ($wpdb->last_error) {
                error_log('Fight_Team_Students_Dashboard: Database error fetching students: ' . $wpdb->last_error);
                return '<p>' . __('Erro ao carregar alunos. Contate o administrador.', 'fight-team') . '</p>';
            }

            // Verificar pagamento do mês atual
            foreach ($students as $student) {
                $payment_status = $wpdb->get_var($wpdb->prepare(
                    "SELECT status
                     FROM $payments_table
                     WHERE student_id = %d
                     AND YEAR(due_date) = YEAR(CURDATE())
                     AND MONTH(due_date) = MONTH(CURDATE())",
                    $student->id
                ));

                $student->payment_status = $payment_status === 'paid' ? __('Pago', 'fight-team') : __('Pendente', 'fight-team');
            }
        }

        ob_start();
        ?>
        <div class="wrap fight-team-shortcode">
            <h1><?php _e('Dashboard de Alunos', 'fight-team'); ?></h1>
            <a href="<?php echo admin_url('admin.php?page=fight-team'); ?>" class="button button-primary"><?php _e('Voltar ao Dashboard', 'fight-team'); ?></a>

            <h2><?php _e('Selecionar Turma', 'fight-team'); ?></h2>
            <form method="get" class="class-filter-form">
                <label for="class_id"><?php _e('Turma', 'fight-team'); ?>:</label>
                <select name="class_id" id="class_id" onchange="this.form.submit()">
                    <option value=""><?php _e('Selecione uma turma', 'fight-team'); ?></option>
                    <?php foreach ($classes as $class): ?>
                        <option value="<?php echo esc_attr($class->id); ?>" <?php echo $selected_class_id == $class->id ? 'selected' : ''; ?>>
                            <?php echo esc_html($class->name . ' (' . $class->schedule . ')'); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </form>

            <?php if ($selected_class_id && !empty($students)): ?>
                <h2><?php _e('Alunos da Turma', 'fight-team'); ?></h2>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th><?php _e('Nome', 'fight-team'); ?></th>
                            <th><?php _e('Telefone', 'fight-team'); ?></th>
                            <th><?php _e('Nível (Faixa)', 'fight-team'); ?></th>
                            <th><?php _e('Datas dos Exames de Nível', 'fight-team'); ?></th>
                            <th><?php _e('Pagamento Mês Atual', 'fight-team'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($students as $student): ?>
                            <tr>
                                <td><?php echo esc_html($student->full_name); ?></td>
                                <td><?php echo esc_html($student->phone ?: '-'); ?></td>
                                <td><?php echo esc_html($student->belt_level ?: '-'); ?></td>
                                <td><?php echo esc_html($student->exam_dates ?: '-'); ?></td>
                                <td><?php echo esc_html($student->payment_status); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php elseif ($selected_class_id): ?>
                <p><?php _e('Nenhum aluno encontrado para esta turma.', 'fight-team'); ?></p>
            <?php else: ?>
                <p><?php _e('Por favor, selecione uma turma para visualizar os alunos.', 'fight-team'); ?></p>
            <?php endif; ?>
        </div>
        <?php
        $output = ob_get_clean();
        error_log('Fight_Team_Students_Dashboard: Students dashboard shortcode rendered');
        return $output;
    }
}
?>