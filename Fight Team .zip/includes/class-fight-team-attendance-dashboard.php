<?php
// includes/class-fight-team-attendance-dashboard.php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class Fight_Team_Attendance_Dashboard {
    public function __construct() {
        add_action('admin_menu', array($this, 'add_attendance_dashboard_menu'));
        error_log('Fight_Team_Attendance_Dashboard: Constructor called');
    }

    public function add_attendance_dashboard_menu() {
        add_submenu_page(
            'fight-team',
            __('Dashboard de Presenças', 'fight-team'),
            __('Dashboard de Presenças', 'fight-team'),
            'manage_options',
            'fight-team-attendance-dashboard',
            array($this, 'render_attendance_dashboard_page')
        );
        error_log('Fight_Team_Attendance_Dashboard: Attendance dashboard menu added');
    }

    public function render_attendance_dashboard_page() {
        if (!current_user_can('manage_options')) {
            wp_die(__('Sem permissão para acessar esta página.', 'fight-team'));
        }

        global $wpdb;
        $academy_name = get_option('fight_team_academy_name', 'Minha Academia');
        
        // Obter mês e ano selecionados ou usar o mês atual
        $selected_month = isset($_GET['month']) ? intval($_GET['month']) : date('m');
        $selected_year = isset($_GET['year']) ? intval($_GET['year']) : date('Y');

        // Validar mês e ano
        $selected_month = ($selected_month >= 1 && $selected_month <= 12) ? $selected_month : date('m');
        $selected_year = ($selected_year >= 2000 && $selected_year <= 9999) ? $selected_year : date('Y');

        // Calcular datas do mês
        $start_date = sprintf('%04d-%02d-01', $selected_year, $selected_month);
        $end_date = date('Y-m-t', strtotime($start_date)); // Último dia do mês

        // Consultar alunos, suas faltas e presenças
        $students = $wpdb->get_results($wpdb->prepare("
            SELECT 
                s.id, 
                s.full_name, 
                COALESCE(SUM(CASE WHEN a.present = 0 THEN 1 ELSE 0 END), 0) as absences,
                COALESCE(SUM(CASE WHEN a.present = 1 THEN 1 ELSE 0 END), 0) as presences
            FROM {$wpdb->prefix}fight_team_students s
            LEFT JOIN {$wpdb->prefix}fight_team_attendances a 
                ON s.id = a.student_id 
                AND a.attendance_date BETWEEN %s AND %s
            WHERE s.active = 1
            GROUP BY s.id, s.full_name
            ORDER BY s.full_name ASC
        ", $start_date, $end_date));

        error_log('Fight_Team_Attendance_Dashboard: Rendering attendance dashboard page with month=' . $selected_month . ', year=' . $selected_year);
        ?>
        <div class="wrap">
            <h1><?php echo esc_html($academy_name); ?> - <?php _e('Dashboard de Presenças', 'fight-team'); ?></h1>
            <form method="get">
                <input type="hidden" name="page" value="fight-team-attendance-dashboard">
                <div class="form-group">
                    <label for="month"><?php _e('Mês', 'fight-team'); ?></label>
                    <select id="month" name="month" required>
                        <?php for ($m = 1; $m <= 12; $m++): ?>
                            <option value="<?php echo $m; ?>" <?php selected($selected_month, $m); ?>>
                                <?php echo esc_html(date_i18n('F', mktime(0, 0, 0, $m, 1))); ?>
                            </option>
                        <?php endfor; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="year"><?php _e('Ano', 'fight-team'); ?></label>
                    <input type="number" id="year" name="year" value="<?php echo esc_attr($selected_year); ?>" min="2000" max="9999" required>
                </div>
                <?php submit_button(__('Filtrar', 'fight-team'), 'secondary'); ?>
            </form>

            <h2><?php printf(__('Presenças e Faltas em %s/%s', 'fight-team'), esc_html($selected_month), esc_html($selected_year)); ?></h2>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th><?php _e('Nome do Aluno', 'fight-team'); ?></th>
                        <th><?php _e('Total de Presenças', 'fight-team'); ?></th>
                        <th><?php _e('Total de Faltas', 'fight-team'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($students): ?>
                        <?php foreach ($students as $student): ?>
                            <tr>
                                <td><?php echo esc_html($student->full_name); ?></td>
                                <td><?php echo esc_html($student->presences); ?></td>
                                <td><?php echo esc_html($student->absences); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="3"><?php _e('Nenhum aluno encontrado.', 'fight-team'); ?></td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php
        error_log('Fight_Team_Attendance_Dashboard: Attendance dashboard page rendered');
    }
}
?>