jQuery(document).ready(function($) {
    console.log('Fight Team Admin JS: Initializing');

    var $classSelect = $('#class_id');
    var $tableContainer = $('#students-table-container');

    if ($classSelect.length) {
        console.log('Fight Team Admin JS: class_id select found');

        $classSelect.on('change', function() {
            var classId = $(this).val();
            console.log('Fight Team Admin JS: Selected class ID = ' + classId);

            if (!classId) {
                $tableContainer.html('<p><?php _e('Selecione uma turma para ver os alunos ativos.', 'fight-team'); ?></p>');
                console.log('Fight Team Admin JS: No class selected, resetting table container');
                return;
            }

            $tableContainer.html('<p><?php _e('Carregando alunos...', 'fight-team'); ?></p>');
            console.log('Fight Team Admin JS: Sending AJAX request for class ID = ' + classId);

            $.ajax({
                url: fightTeamAjax.ajax_url,
                type: 'POST',
                data: {
                    action: 'get_class_students',
                    nonce: fightTeamAjax.nonce,
                    class_id: classId
                },
                success: function(response) {
                    console.log('Fight Team Admin JS: AJAX success', response);
                    if (response.success && response.data && response.data.students) {
                        var students = response.data.students;
                        if (students.length === 0) {
                            $tableContainer.html('<p><?php _e('Nenhum aluno ativo inscrito nesta turma.', 'fight-team'); ?></p>');
                            console.log('Fight Team Admin JS: No students found');
                            return;
                        }

                        var tableHtml = '<table class="wp-list-table widefat fixed striped">' +
                            '<thead>' +
                            '<tr>' +
                            '<th><?php _e('Nome do Aluno', 'fight-team'); ?></th>' +
                            '<th><?php _e('Status', 'fight-team'); ?></th>' +
                            '<th><?php _e('Presenças no Mês', 'fight-team'); ?></th>' +
                            '<th><?php _e('Tempo de Treino', 'fight-team'); ?></th>' +
                            '</tr>' +
                            '</thead>' +
                            '<tbody>';

                        $.each(students, function(index, student) {
                            tableHtml += '<tr>' +
                                '<td>' + student.full_name + '</td>' +
                                '<td>' + student.status + '</td>' +
                                '<td>' + student.attendances + '</td>' +
                                '<td>' + student.training_time + '</td>' +
                                '</tr>';
                        });

                        tableHtml += '</tbody></table>';
                        $tableContainer.html(tableHtml);
                        console.log('Fight Team Admin JS: Table rendered with ' + students.length + ' students');
                    } else {
                        $tableContainer.html('<p><?php _e('Erro ao carregar alunos. Tente novamente.', 'fight-team'); ?></p>');
                        console.log('Fight Team Admin JS: Invalid response or no students', response);
                    }
                },
                error: function(xhr, status, error) {
                    $tableContainer.html('<p><?php _e('Erro ao carregar alunos. Tente novamente.', 'fight-team'); ?></p>');
                    console.error('Fight Team Admin JS: AJAX error', status, error, xhr.responseText);
                }
            });
        });
    } else {
        console.log('Fight Team Admin JS: class_id select not found');
    }
});