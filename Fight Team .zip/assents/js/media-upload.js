jQuery(document).ready(function($) {
    console.log('media-upload.js loaded');

    // Verificar se o WordPress Media Uploader está disponível
    if (typeof wp === 'undefined' || typeof wp.media === 'undefined') {
        console.error('WordPress Media Uploader não está carregado. Verifique se wp.media foi enfileirado.');
        return;
    }

    // Definir valores padrão para fightTeamMedia
    var fightTeamMedia = window.fightTeamMedia || {
        title: 'Selecionar Foto do Aluno',
        button: 'Usar Foto'
    };

    var mediaUploader;

    // Evento de clique no botão de upload
    $('#upload_photo_button').on('click', function(e) {
        e.preventDefault();
        console.log('Botão de upload clicado');

        // Reutilizar o uploader se já estiver instanciado
        if (mediaUploader) {
            mediaUploader.open();
            return;
        }

        // Configurar o Media Uploader
        mediaUploader = wp.media({
            title: fightTeamMedia.title,
            button: {
                text: fightTeamMedia.button
            },
            multiple: false, // Permitir apenas uma imagem
            library: {
                type: ['image/jpeg', 'image/png'] // Restringir a JPG e PNG
            }
        });

        // Quando uma imagem é selecionada
        mediaUploader.on('select', function() {
            var attachment = mediaUploader.state().get('selection').first().toJSON();
            console.log('Imagem selecionada:', attachment.url);

            // Atualizar o campo de input com a URL da imagem
            $('#photo_url').val(attachment.url);

            // Exibir prévia da imagem
            $('#photo_preview').html(
                '<img src="' + attachment.url + '" style="max-width: 100px; max-height: 100px; object-fit: cover;" alt="Prévia da imagem">'
            );
        });

        // Log quando o uploader é aberto
        mediaUploader.on('open', function() {
            console.log('Media Uploader aberto');
        });

        // Abrir o Media Uploader
        mediaUploader.open();
    });
});