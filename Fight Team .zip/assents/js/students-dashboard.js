jQuery(document).ready(function($) {
    // JavaScript para interações futuras, se necessário
    console.log('Fight Team Students Dashboard JS loaded');
});